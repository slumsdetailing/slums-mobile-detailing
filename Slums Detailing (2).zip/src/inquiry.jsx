/* =====================================================================
   INQUIRY MODAL · global quote form on every page
   Vehicle → Service → (Package) → Contact → Confirmation
   ===================================================================
   Usage: <InquiryModal open onClose seedService seedPackage />
   =================================================================== */

function InquiryModal({ open, onClose, seedService = null, seedPackage = null, seedVehicle = null }) {
  const [step, setStep] = React.useState(1);
  const [submitted, setSubmitted] = React.useState(false);
  const [form, setForm] = React.useState({
    vehicle: seedVehicle || "",
    service: seedService || "",
    package: seedPackage || "",
    year: "",
    make: "",
    name: "",
    phone: "",
    email: "",
    address: "",
    date: "",
    notes: "",
  });
  const [errors, setErrors] = React.useState({});

  React.useEffect(() => {
    if (open) {
      setForm(f => ({
        ...f,
        vehicle: seedVehicle || f.vehicle,
        service: seedService || f.service,
        package: seedPackage || f.package,
      }));
      setStep(seedService || seedPackage ? 2 : 1);
      setSubmitted(false);
      setErrors({});
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => { document.body.style.overflow = ""; };
  }, [open, seedService, seedPackage, seedVehicle]);

  const update = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const packagesForService = form.service
    ? PACKAGES.filter(p => {
        if (form.service === "detail") return p.category === "detail";
        if (form.service === "ceramic") return p.category === "ceramic";
        if (form.service === "biohazard") return p.category === "biohazard";
        return false;
      })
    : [];

  const validate = (s) => {
    const e = {};
    if (s === 1) {
      if (!form.vehicle) e.vehicle = "select one";
      if (!form.service) e.service = "select one";
    }
    if (s === 2) {
      if (!form.year.trim()) e.year = "required";
      if (!form.make.trim()) e.make = "required";
    }
    if (s === 3) {
      if (!form.name.trim()) e.name = "required";
      if (!/^[\d\s\-\(\)\+]{7,}$/.test(form.phone)) e.phone = "valid phone required";
      if (form.email && !/^\S+@\S+\.\S+$/.test(form.email)) e.email = "valid email";
      if (!form.address.trim()) e.address = "required";
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const next = () => {
    if (validate(step)) {
      // step 2 always shown for package pick if service has packages
      if (step === 1 && form.service === "plan") {
        // maintenance has plans selected on the dedicated page; jump to contact
        setStep(3);
      } else {
        setStep(step + 1);
      }
    }
  };

  const submit = () => { if (validate(3)) setSubmitted(true); };

  if (!open) return null;

  const totalSteps = 3;

  return (
    <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm" role="dialog" aria-modal="true" aria-labelledby="inquiry-title">
      <div className="absolute inset-0" onClick={onClose}></div>
      <div className="relative bg-ink-900 border border-white/10 w-full sm:max-w-[640px] sm:max-h-[92vh] max-h-[95vh] overflow-y-auto">
        {/* header */}
        <div className="sticky top-0 bg-ink-900/95 backdrop-blur border-b border-white/8 px-6 py-4 flex items-center justify-between z-10">
          <div>
            <div className="font-mono text-[10px] tracking-[.22em] text-blood-500 uppercase">// QUOTE REQUEST</div>
            <h2 id="inquiry-title" className="font-display text-[24px] text-bone leading-tight mt-1">Tell us about your vehicle</h2>
          </div>
          <button onClick={onClose} className="w-9 h-9 border border-white/10 hover:border-blood-500/50 hover:text-blood-400 flex items-center justify-center transition-colors" aria-label="Close">
            <Icon.Close />
          </button>
        </div>

        <div className="p-6 lg:p-8">
          {/* progress */}
          <div className="flex items-center justify-between mb-7">
            <div className="font-mono text-[10px] tracking-[.22em] text-white/40 uppercase">
              {submitted ? "RECEIVED" : `STEP ${step} / ${totalSteps}`}
            </div>
            <div className="flex gap-2">
              {Array.from({ length: totalSteps }).map((_, i) => (
                <div key={i} className={`h-1 w-10 transition-all ${(submitted || (i + 1) <= step) ? "bg-blood-500" : "bg-white/10"}`}></div>
              ))}
            </div>
          </div>

          {submitted ? (
            <div className="py-8 text-center">
              <div className="w-16 h-16 bg-blood-500/15 border border-blood-500/40 rounded-full mx-auto flex items-center justify-center text-blood-400">
                <Icon.Check />
              </div>
              <h3 className="font-display text-[40px] text-bone mt-5 leading-none">You're on the list.</h3>
              <p className="text-white/60 text-[14px] mt-4 max-w-[400px] mx-auto leading-[1.7]">
                Dominick will text <span className="text-blood-400 font-mono">{form.phone}</span> within the hour (business hours) with a firm quote for your {form.year} {form.make}.
              </p>
              <div className="mt-7 flex items-center justify-center gap-3">
                <a href={BUSINESS.phoneHref} className="btn-ghost px-5 py-3 rounded-sm text-[11px] uppercase tracking-[.16em] flex items-center gap-2">
                  <Icon.Phone /> Call Now
                </a>
                <button onClick={onClose} className="btn-primary px-5 py-3 rounded-sm text-[11px] uppercase tracking-[.16em]">Done</button>
              </div>
            </div>
          ) : (
            <>
              {/* STEP 1 — Vehicle + Service */}
              {step === 1 && (
                <div className="space-y-7">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <label className="field-label">Vehicle Type</label>
                      {errors.vehicle && <span className="font-mono text-[10px] text-blood-400">! {errors.vehicle}</span>}
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {VEHICLES.map(v => {
                        const IconEl = Icon[v.icon] || Icon.Car;
                        const on = form.vehicle === v.id;
                        return (
                          <button key={v.id} type="button" onClick={() => update("vehicle", v.id)}
                            className={`p-3 border text-center transition-all ${on ? "bg-blood-500/15 border-blood-500/55 text-bone" : "bg-ink-800 border-white/10 text-white/70 hover:border-white/25"}`}>
                            <span className={`inline-flex justify-center ${on ? "text-blood-400" : "text-white/55"}`}><IconEl /></span>
                            <div className="text-[11.5px] mt-2 leading-tight">{v.name}</div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <label className="field-label">Service Interested In</label>
                      {errors.service && <span className="font-mono text-[10px] text-blood-400">! {errors.service}</span>}
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {SERVICES.map(s => {
                        const on = form.service === s.id;
                        const IconEl = Icon[s.icon] || Icon.Drop;
                        return (
                          <button key={s.id} type="button" onClick={() => { update("service", s.id); update("package", ""); }}
                            className={`p-3 text-left border transition-all ${on ? "bg-blood-500/12 border-blood-500/55" : "bg-ink-800 border-white/10 hover:border-white/25"}`}>
                            <div className="flex items-center gap-2">
                              <span className={on ? "text-blood-400" : "text-blood-500/70"}><IconEl /></span>
                              <span className="text-[13px] text-bone">{s.name}</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* STEP 2 — Vehicle details + optional package */}
              {step === 2 && (
                <div className="space-y-5">
                  <div className="grid grid-cols-3 gap-3">
                    <Field label="Year" k="year" form={form} update={update} errors={errors} placeholder="2023" />
                    <div className="col-span-2">
                      <Field label="Make · Model" k="make" form={form} update={update} errors={errors} placeholder="BMW M3 Competition" />
                    </div>
                  </div>

                  {packagesForService.length > 0 && (
                    <div>
                      <label className="field-label block mb-2">Package · optional</label>
                      <div className="grid gap-2 max-h-[260px] overflow-y-auto pr-1">
                        {packagesForService.map(p => {
                          const on = form.package === p.id;
                          const price = p.custom ? "Custom" : `From $${p.pricing[form.vehicle] || p.base}`;
                          return (
                            <button key={p.id} type="button" onClick={() => update("package", on ? "" : p.id)}
                              className={`text-left border p-3 transition-all ${on ? "bg-blood-500/12 border-blood-500/55" : "bg-ink-800 border-white/10 hover:border-white/25"}`}>
                              <div className="flex items-center justify-between gap-3">
                                <div>
                                  <div className="text-[13px] text-bone leading-tight">{p.name}</div>
                                  <div className="text-[11.5px] text-white/55 mt-0.5">{p.tagline}</div>
                                </div>
                                <div className="font-mono text-[11px] text-blood-400 whitespace-nowrap">{price}</div>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* STEP 3 — Contact + address */}
              {step === 3 && (
                <div className="space-y-5">
                  <Field label="Your Name" k="name" form={form} update={update} errors={errors} placeholder="Dominick Smith" />
                  <div className="grid sm:grid-cols-2 gap-3">
                    <Field label="Phone" k="phone" form={form} update={update} errors={errors} placeholder="(304) 555-0199" />
                    <Field label="Email · optional" k="email" form={form} update={update} errors={errors} placeholder="you@example.com" />
                  </div>
                  <Field label="Service Address" k="address" form={form} update={update} errors={errors} placeholder="123 Winchester Ave, Martinsburg WV" />
                  <Field label="Preferred Date · optional" k="date" form={form} update={update} errors={errors} type="date" />
                  <div>
                    <label className="field-label block mb-2">Anything we should know? · optional</label>
                    <textarea
                      className="field min-h-[90px] resize-none"
                      value={form.notes} onChange={(e) => update("notes", e.target.value)}
                      placeholder="Heavy pet hair, sticky residue, want ceramic added on, etc."
                    ></textarea>
                  </div>
                </div>
              )}

              {/* footer */}
              <div className="mt-8 pt-5 border-t border-white/8 flex items-center justify-between gap-4 flex-wrap">
                <div className="font-mono text-[10px] tracking-[.18em] text-white/40 uppercase">
                  {form.vehicle ? VEHICLES.find(v => v.id === form.vehicle)?.name : "—"}
                  {" · "}
                  {form.service ? SERVICES.find(s => s.id === form.service)?.name : "—"}
                </div>
                <div className="flex items-center gap-3">
                  {step > 1 && (
                    <button onClick={() => setStep(step - 1)} className="btn-ghost px-5 py-3 rounded-sm text-[11px] uppercase tracking-[.16em] flex items-center gap-2">
                      <Icon.ArrowL /> Back
                    </button>
                  )}
                  {step < totalSteps ? (
                    <button onClick={next} className="btn-primary px-6 py-3 rounded-sm text-[11px] uppercase tracking-[.16em] flex items-center gap-2">
                      Continue <Icon.Arrow />
                    </button>
                  ) : (
                    <button onClick={submit} className="btn-primary px-6 py-3 rounded-sm text-[11px] uppercase tracking-[.16em] flex items-center gap-2">
                      Send Request <Icon.Send />
                    </button>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function Field({ label, k, form, update, errors, type = "text", placeholder }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <label className="field-label">{label}</label>
        {errors[k] && <span className="font-mono text-[10px] tracking-[.18em] text-blood-400 uppercase">! {errors[k]}</span>}
      </div>
      <input
        type={type}
        className={`field ${errors[k] ? "border-blood-500/60" : ""}`}
        value={form[k]} onChange={(e) => update(k, e.target.value)}
        placeholder={placeholder}
      />
    </div>
  );
}

window.InquiryModal = InquiryModal;
