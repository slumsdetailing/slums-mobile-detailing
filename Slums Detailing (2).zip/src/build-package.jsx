/* =====================================================================
   BUILD A COMPLETE PACKAGE  · in-page multi-step inquiry section
   =====================================================================
   Lives at the bottom of every page. 1-2-3 dropdown / stepper:

   Step 1 · "What are we working on?"  Year / Make / Model
   Step 2 · "Which services?"           Multi-pick — each pick reveals
                                        its own customization block:
                                         · Auto Detailing → category
                                           (interior · exterior · full)
                                           → package + add-ons + price
                                         · Ceramic Coating → surfaces
                                           (paint · glass · wheels · interior)
                                           with Select-All / Clear  (no $)
                                         · Maintenance → plan
                                         · Bio-Hazard → quote-only note
   Step 3 · "Your details"              Name + phone + address + send
   =================================================================== */

function BuildPackageSection({ id = "build" }) {
  const [step, setStep]   = React.useState(1);
  const [open, setOpen]   = React.useState({ 1: true, 2: false, 3: false });
  const [submitted, setSubmitted] = React.useState(false);

  /* ---- form state ---- */
  const [vehicle, setVehicle] = React.useState({
    type: "sedan", year: "", make: "", model: "",
  });
  const [services, setServices] = React.useState([]); // ["detail","ceramic","plan","biohazard"]

  // detail config
  const [detailPkg,  setDetailPkg]  = React.useState("");
  const [detailAddons, setDetailAddons] = React.useState([]);

  // ceramic config — surfaces
  const [ceramicSurfaces, setCeramicSurfaces] = React.useState([]);

  // maintenance
  const [planId, setPlanId] = React.useState("");

  // contact
  const [contact, setContact] = React.useState({ name: "", phone: "", email: "", address: "", notes: "" });
  const [errors, setErrors]   = React.useState({});

  /* ---- helpers ---- */
  const toggleService = (id) => {
    setServices(arr => {
      const next = arr.includes(id) ? arr.filter(x => x !== id) : [...arr, id];
      return next;
    });
  };
  const toggleAddon = (id) =>
    setDetailAddons(arr => arr.includes(id) ? arr.filter(x => x !== id) : [...arr, id]);
  const toggleSurface = (id) =>
    setCeramicSurfaces(arr => arr.includes(id) ? arr.filter(x => x !== id) : [...arr, id]);

  /* ---- live pricing ---- */
  const DETAIL_GROUPS = [
    {
      id: "interior",
      title: "Interior Detail",
      sub: "Carpets, seats, headliner, vents.",
      packageIds: ["express-interior", "executive-deep-cleaning"],
    },
    {
      id: "exterior",
      title: "Exterior Detail",
      sub: "Paint, wheels, glass, sealant.",
      packageIds: ["express-clay-seal", "executive-buff-seal"],
    },
    {
      id: "full",
      title: "Full Detail",
      sub: "Everything — inside out, top to bottom.",
      packageIds: ["express-full", "luxury-full"],
    },
  ];
  const selectedPkg = PACKAGES.find(p => p.id === detailPkg);
  const detailBase = selectedPkg ? (selectedPkg.pricing[vehicle.type] || selectedPkg.base) : 0;
  const detailAddonTotal = detailAddons.reduce((s, id) => s + (ADDONS.find(a => a.id === id)?.price || 0), 0);
  const selectedPlan = PLANS.find(p => p.id === planId);

  const detailTotal = detailBase + detailAddonTotal;
  const monthlyTotal = selectedPlan ? selectedPlan.price : 0;
  const oneTimeTotal = detailTotal;
  const hasCeramic = services.includes("ceramic");
  const hasBio = services.includes("biohazard");

  /* ---- step open/close ---- */
  const goStep = (n) => {
    setStep(n);
    setOpen(o => ({ ...o, [n]: true }));
  };

  // auto-open step 2 when vehicle filled
  React.useEffect(() => {
    if (vehicle.year && vehicle.make && vehicle.model && step === 1) {
      setOpen(o => ({ ...o, 2: true }));
    }
  }, [vehicle, step]);

  /* ---- submit ---- */
  const validate = () => {
    const e = {};
    if (!vehicle.year.trim())  e.year  = "required";
    if (!vehicle.make.trim())  e.make  = "required";
    if (!vehicle.model.trim()) e.model = "required";
    if (services.length === 0) e.services = "pick at least one service";
    if (!contact.name.trim())  e.name = "required";
    if (!/^[\d\s\-\(\)\+]{7,}$/.test(contact.phone)) e.phone = "valid phone required";
    if (contact.email && !/^\S+@\S+\.\S+$/.test(contact.email)) e.email = "valid email";
    if (!contact.address.trim()) e.address = "required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = () => {
    if (validate()) {
      setSubmitted(true);
      // scroll the confirmation into view
      setTimeout(() => {
        document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 60);
    } else {
      // open all steps so user sees the failures
      setOpen({ 1: true, 2: true, 3: true });
    }
  };

  /* ---------------- RENDER ---------------- */
  return (
    <section id={id} className="relative bg-ink-800 py-20 lg:py-28 border-t border-white/5">
      <div className="absolute inset-0 halo opacity-40 pointer-events-none"></div>
      <div className="relative max-w-[1200px] mx-auto px-5 lg:px-10">
        {/* header */}
        <div className="max-w-[820px]">
          <div className="font-mono text-[11px] tracking-[.22em] text-blood-500 uppercase mb-5">// BUILD A COMPLETE PACKAGE</div>
          <h2 className="font-display text-[44px] sm:text-[64px] lg:text-[84px] leading-[0.9] tracking-[-0.01em] text-bone text-balance">
            Pick the vehicle.<br/>Build the <span className="text-blood-500">package</span>.<br/>Get a real <span className="text-rose-500">quote</span>.
          </h2>
          <p className="mt-5 text-white/65 text-[14.5px] leading-[1.7] max-w-[640px] text-pretty">
            Three steps. Stack any combination of services — detailing, ceramic, maintenance, bio-hazard — and we'll text back a firm quote within the hour during business hours.
          </p>
        </div>

        {submitted ? (
          <Submitted contact={contact} vehicle={vehicle} services={services} detailPkg={selectedPkg} ceramicSurfaces={ceramicSurfaces} plan={selectedPlan} onReset={() => { setSubmitted(false); setStep(1); setOpen({1:true,2:false,3:false}); }} />
        ) : (
          <div className="mt-12 space-y-3">
            {/* ===================== STEP 1 ===================== */}
            <StepShell
              n="01"
              title="What are we working on?"
              hint="Year / make / model"
              isOpen={open[1]}
              onToggle={() => setOpen(o => ({ ...o, 1: !o[1] }))}
              status={vehicle.year && vehicle.make && vehicle.model ? `${vehicle.year} ${vehicle.make} ${vehicle.model}` : null}
            >
              <div className="grid sm:grid-cols-12 gap-3">
                <div className="sm:col-span-3">
                  <Lbl k="Year" err={errors.year} />
                  <input value={vehicle.year} onChange={(e) => setVehicle({ ...vehicle, year: e.target.value })}
                    placeholder="2023" className={`field ${errors.year ? "border-rose-500/55" : ""}`} />
                </div>
                <div className="sm:col-span-4">
                  <Lbl k="Make" err={errors.make} />
                  <input value={vehicle.make} onChange={(e) => setVehicle({ ...vehicle, make: e.target.value })}
                    placeholder="BMW" className={`field ${errors.make ? "border-rose-500/55" : ""}`} />
                </div>
                <div className="sm:col-span-5">
                  <Lbl k="Model" err={errors.model} />
                  <input value={vehicle.model} onChange={(e) => setVehicle({ ...vehicle, model: e.target.value })}
                    placeholder="M3 Competition" className={`field ${errors.model ? "border-rose-500/55" : ""}`} />
                </div>
              </div>

              <DidYouKnow text="Final pricing varies a bit by body style — trucks and SUVs take longer and use more product than sedans and motorcycles. A sedan M3 quotes lower than a Tahoe of the same year, by design." />

              <div className="mt-4 flex justify-end">
                <button onClick={() => { setStep(2); setOpen(o => ({ ...o, 2: true })); }}
                  disabled={!(vehicle.year && vehicle.make && vehicle.model)}
                  className="btn-primary px-5 py-3 rounded-sm text-[11px] uppercase tracking-[.16em] flex items-center gap-2">
                  Continue · Step 2 <Icon.Arrow />
                </button>
              </div>
            </StepShell>

            {/* ===================== STEP 2 ===================== */}
            <StepShell
              n="02"
              title="Which services?"
              hint="Pick one or stack a few — each adds its own customization step"
              isOpen={open[2]}
              onToggle={() => setOpen(o => ({ ...o, 2: !o[2] }))}
              status={services.length ? `${services.length} selected` : null}
            >
              <ServiceChips selected={services} onToggle={toggleService} />
              {errors.services && services.length === 0 && (
                <div className="mt-2 font-mono text-[10px] tracking-[.18em] uppercase text-rose-500">! {errors.services}</div>
              )}

              {/* ---------- DETAIL config ---------- */}
              {services.includes("detail") && (
                <SubBlock title="Auto Detailing" sub="Pick any one package across the three categories.">
                  {DETAIL_GROUPS.map((group, gi) => {
                    const groupPkgs = group.packageIds.map(id => PACKAGES.find(p => p.id === id)).filter(Boolean);
                    return (
                      <div key={group.id} className={gi > 0 ? "mt-6 pt-6 border-t border-white/8" : ""}>
                        <div className="flex items-baseline justify-between mb-3 flex-wrap gap-2">
                          <div className="flex items-baseline gap-3">
                            <span className="font-mono text-[10px] tracking-[.22em] text-blood-500 uppercase">CAT/0{gi + 1}</span>
                            <h5 className="font-display text-[26px] text-bone leading-none">{group.title}</h5>
                          </div>
                          <div className="font-mono text-[10.5px] tracking-[.2em] text-white/45 uppercase">{group.sub}</div>
                        </div>
                        <div className="grid sm:grid-cols-2 gap-2">
                          {groupPkgs.map(p => {
                            const on = detailPkg === p.id;
                            const price = p.pricing.sedan || p.base;
                            return (
                              <button key={p.id} type="button" onClick={() => setDetailPkg(on ? "" : p.id)}
                                className={`text-left p-4 border transition-all ${on ? "bg-blood-500/12 border-blood-500/55" : "bg-ink-800 border-white/10 hover:border-white/25"}`}>
                                <div className="flex items-start justify-between gap-3">
                                  <div className="min-w-0">
                                    <div className="text-[13.5px] text-bone leading-tight">{p.name}</div>
                                    <div className="text-[11.5px] text-white/55 mt-1 leading-snug">{p.tagline}</div>
                                    <div className="font-mono text-[10px] tracking-[.18em] text-white/40 uppercase mt-1.5">{p.duration}</div>
                                  </div>
                                  <div className="text-right whitespace-nowrap">
                                    <div className="font-mono text-[9.5px] tracking-[.2em] text-white/40 uppercase">FROM</div>
                                    <div className="font-display text-[26px] text-blood-400 leading-none mt-0.5">${price}</div>
                                  </div>
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}

                  {/* add-ons */}
                  <div className="mt-5">
                    <div className="flex items-center justify-between mb-2">
                      <div className="font-mono text-[10px] tracking-[.22em] text-white/45 uppercase">Add-Ons (Auto Detailing)</div>
                      <div className="font-mono text-[10px] tracking-[.18em] text-white/40">{detailAddons.length} selected</div>
                    </div>
                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
                      {ADDONS.map(a => {
                        const on = detailAddons.includes(a.id);
                        return (
                          <button key={a.id} type="button" onClick={() => toggleAddon(a.id)}
                            className={`text-left p-3 border transition-all flex items-start justify-between gap-3 ${on ? "bg-blood-500/12 border-blood-500/55" : "bg-ink-800 border-white/10 hover:border-white/25"}`}>
                            <div className="min-w-0">
                              <div className="text-[12.5px] text-bone leading-tight">{a.name}</div>
                              <div className="text-[10.5px] text-white/50 mt-0.5 leading-snug">{a.blurb}</div>
                            </div>
                            <div className="font-mono text-[11px] text-blood-400">+${a.price}</div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <ConditionDisclaimer className="mt-4" />
                </SubBlock>
              )}

              {/* ---------- CERAMIC config ---------- */}
              {services.includes("ceramic") && (
                <SubBlock title="Ceramic Coating" sub="Tell us what surfaces — we'll quote based on inspection.">
                  <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                    <div className="font-mono text-[10px] tracking-[.22em] text-white/45 uppercase">Surfaces to coat</div>
                    <div className="flex gap-2">
                      <button type="button"
                        onClick={() => setCeramicSurfaces(["paint","glass","wheels","interior"])}
                        className="font-mono text-[10px] tracking-[.18em] uppercase px-3 py-1.5 border border-blood-500/30 text-blood-400 hover:bg-blood-500/8">
                        Select all
                      </button>
                      <button type="button"
                        onClick={() => setCeramicSurfaces([])}
                        className="font-mono text-[10px] tracking-[.18em] uppercase px-3 py-1.5 border border-white/10 text-white/55 hover:border-white/25">
                        Clear
                      </button>
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-2">
                    {[
                      ["paint",    "Paint",    "Full body · 3yr or 5yr Gyeon"],
                      ["glass",    "Glass",    "Windshield + windows · rain-shed"],
                      ["wheels",   "Wheels",   "Face + caliper · brake-dust resistant"],
                      ["interior", "Interior", "Leather, plastic, fabric · spill-shed"],
                    ].map(([k, l, blurb]) => {
                      const on = ceramicSurfaces.includes(k);
                      return (
                        <button key={k} type="button" onClick={() => toggleSurface(k)}
                          className={`text-left p-4 border transition-all ${on ? "bg-blood-500/12 border-blood-500/55" : "bg-ink-800 border-white/10 hover:border-white/25"}`}>
                          <div className="flex items-center justify-between mb-1.5">
                            <div className="text-[13px] text-bone">{l}</div>
                            <span className={`w-4 h-4 border ${on ? "bg-blood-500 border-blood-500" : "border-white/25"} flex items-center justify-center`}>
                              {on && <span className="text-ink-900 scale-75"><Icon.Check /></span>}
                            </span>
                          </div>
                          <div className="text-[11px] text-white/55 leading-snug">{blurb}</div>
                        </button>
                      );
                    })}
                  </div>

                  <div className="mt-4 bg-blood-500/5 border border-blood-500/20 p-3 font-mono text-[10.5px] tracking-[.18em] text-blood-300 uppercase">
                    Ceramic is custom-quoted on inspection · we evaluate paint condition before pricing
                  </div>
                </SubBlock>
              )}

              {/* ---------- MAINTENANCE config ---------- */}
              {services.includes("plan") && (
                <SubBlock title="Maintenance Program" sub="Cadence + prepay discount available after we talk.">
                  <div className="grid sm:grid-cols-3 gap-2">
                    {PLANS.map(p => {
                      const on = planId === p.id;
                      return (
                        <button key={p.id} type="button" onClick={() => setPlanId(on ? "" : p.id)}
                          className={`text-left p-4 border transition-all ${on ? "bg-blood-500/12 border-blood-500/55" : "bg-ink-800 border-white/10 hover:border-white/25"}`}>
                          <div className="font-mono text-[10px] tracking-[.2em] text-blood-500 uppercase">{p.cadence}</div>
                          <div className="text-[13.5px] text-bone mt-1">{p.name}</div>
                          <div className="mt-2 flex items-baseline gap-1.5">
                            <span className="font-display text-[28px] text-bone leading-none">${p.price}</span>
                            <span className="text-white/40 text-[11px]">/mo</span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </SubBlock>
              )}

              {/* ---------- BIO-HAZARD config ---------- */}
              {services.includes("biohazard") && (
                <SubBlock title="Bio-Hazard Cleaning" sub="Always custom-quoted on inspection.">
                  <div className="bg-blood-500/5 border border-blood-500/20 p-4 text-[13px] text-white/75 leading-[1.65]">
                    <span className="font-semibold text-blood-300">Why it's quote-only · </span>
                    Bio-hazard remediation involves regulated waste handling, specialized PPE, hospital-grade chemistry, and ozone shock. Pricing varies wildly with contamination level — we'll inspect within 24 hours and give you a written, confidential quote.
                  </div>
                </SubBlock>
              )}

              <div className="mt-5 flex justify-between flex-wrap gap-3">
                <button onClick={() => goStep(1)}
                  className="btn-ghost px-4 py-3 rounded-sm text-[11px] uppercase tracking-[.16em] flex items-center gap-2">
                  <Icon.ArrowL /> Back
                </button>
                <button onClick={() => { setStep(3); setOpen(o => ({ ...o, 3: true })); }}
                  disabled={services.length === 0}
                  className="btn-primary px-5 py-3 rounded-sm text-[11px] uppercase tracking-[.16em] flex items-center gap-2">
                  Continue · Step 3 <Icon.Arrow />
                </button>
              </div>
            </StepShell>

            {/* ===================== STEP 3 ===================== */}
            <StepShell
              n="03"
              title="Your details"
              hint="Name, contact, address · we'll text you a firm quote"
              isOpen={open[3]}
              onToggle={() => setOpen(o => ({ ...o, 3: !o[3] }))}
              status={contact.name ? contact.name : null}
            >
              <div className="grid sm:grid-cols-12 gap-3">
                <div className="sm:col-span-6">
                  <Lbl k="Your Name" err={errors.name} />
                  <input className={`field ${errors.name ? "border-rose-500/55" : ""}`}
                    value={contact.name} onChange={(e) => setContact({ ...contact, name: e.target.value })} placeholder="Dominick Smith" />
                </div>
                <div className="sm:col-span-6">
                  <Lbl k="Phone" err={errors.phone} />
                  <input className={`field ${errors.phone ? "border-rose-500/55" : ""}`}
                    value={contact.phone} onChange={(e) => setContact({ ...contact, phone: e.target.value })} placeholder="(304) 555-0199" />
                </div>
                <div className="sm:col-span-6">
                  <Lbl k="Email · optional" err={errors.email} />
                  <input className={`field ${errors.email ? "border-rose-500/55" : ""}`}
                    value={contact.email} onChange={(e) => setContact({ ...contact, email: e.target.value })} placeholder="you@example.com" />
                </div>
                <div className="sm:col-span-6">
                  <Lbl k="Service Address" err={errors.address} />
                  <input className={`field ${errors.address ? "border-rose-500/55" : ""}`}
                    value={contact.address} onChange={(e) => setContact({ ...contact, address: e.target.value })} placeholder="123 Winchester Ave, Martinsburg WV" />
                </div>
                <div className="sm:col-span-12">
                  <Lbl k="Anything we should know? · optional" />
                  <textarea className="field min-h-[80px] resize-none"
                    value={contact.notes} onChange={(e) => setContact({ ...contact, notes: e.target.value })}
                    placeholder="Heavy pet hair, sticky residue, scheduling preferences, etc." />
                </div>
              </div>

              {/* live summary card */}
              <div className="mt-5 bg-ink-700 border border-white/10 p-5">
                <div className="font-mono text-[10px] tracking-[.22em] text-blood-500 uppercase mb-3">// YOUR BUILD · LIVE</div>
                <SummaryLine k="Vehicle" v={`${vehicle.year || "—"} ${vehicle.make} ${vehicle.model}`} />

                {services.includes("detail") && (
                  <SummaryLine
                    k="Detailing"
                    v={selectedPkg ? selectedPkg.name : "no package yet"}
                    price={detailTotal > 0 ? `$${detailTotal}` : null}
                  />
                )}
                {services.includes("ceramic") && (
                  <SummaryLine
                    k="Ceramic"
                    v={ceramicSurfaces.length ? ceramicSurfaces.map(s => s[0].toUpperCase() + s.slice(1)).join(" · ") : "no surfaces yet"}
                    price="Quote"
                  />
                )}
                {services.includes("plan") && (
                  <SummaryLine
                    k="Maintenance"
                    v={selectedPlan ? selectedPlan.name : "no plan yet"}
                    price={monthlyTotal ? `$${monthlyTotal}/mo` : null}
                  />
                )}
                {hasBio && (
                  <SummaryLine k="Bio-Hazard" v="Custom inspection" price="Quote" />
                )}

                <div className="mt-3 pt-3 border-t border-white/8 flex items-center justify-between gap-3 flex-wrap">
                  <span className="font-mono text-[10px] tracking-[.2em] text-white/55 uppercase">
                    {oneTimeTotal > 0 ? "One-time estimate" : "Estimate"}
                  </span>
                  <span className="font-display text-[32px] text-blood-400 leading-none">
                    {oneTimeTotal > 0 ? `$${oneTimeTotal}` : (hasCeramic || hasBio ? "Quote" : "—")}
                    {monthlyTotal > 0 && <span className="ml-3 text-bone text-[20px]">+ ${monthlyTotal}/mo</span>}
                  </span>
                </div>
              </div>

              <div className="mt-5 flex justify-between flex-wrap gap-3">
                <button onClick={() => goStep(2)}
                  className="btn-ghost px-4 py-3 rounded-sm text-[11px] uppercase tracking-[.16em] flex items-center gap-2">
                  <Icon.ArrowL /> Back
                </button>
                <button onClick={submit}
                  className="btn-primary px-6 py-4 rounded-sm text-[12px] uppercase tracking-[.16em] flex items-center gap-2">
                  Send My Build To Slums <Icon.Send />
                </button>
              </div>

              <p className="mt-3 font-mono text-[10px] tracking-[.18em] text-white/40 uppercase">
                No spam · no robo-funnels · Dominick texts you back personally
              </p>
            </StepShell>
          </div>
        )}
      </div>
    </section>
  );
}

/* ---------- shared sub-components ----------------------------------- */

function StepShell({ n, title, hint, isOpen, onToggle, status, children }) {
  return (
    <div className="bg-ink-900 border border-white/10 transition-colors">
      <button type="button" onClick={onToggle}
        className="w-full flex items-center gap-5 p-5 lg:p-6 text-left">
        <div className={`flex-shrink-0 w-12 h-12 border flex items-center justify-center font-display text-[22px] ${isOpen ? "bg-blood-500 text-ink-900 border-blood-500" : "border-white/12 text-bone"}`}>
          {n}
        </div>
        <div className="flex-1 min-w-0">
          <div className="font-display text-[26px] sm:text-[32px] text-bone leading-tight">{title}</div>
          <div className="font-mono text-[10.5px] tracking-[.2em] text-white/45 uppercase mt-1">{hint}</div>
        </div>
        {status && (
          <div className="hidden sm:block max-w-[260px] truncate font-mono text-[11px] tracking-[.18em] text-blood-400 uppercase text-right">
            {status}
          </div>
        )}
        <span className={`w-9 h-9 rounded-full border flex items-center justify-center transition-all ${isOpen ? "bg-rose-500 border-rose-500 text-ink-900 rotate-180" : "border-white/15 text-bone"}`}>
          {isOpen ? <Icon.Minus /> : <Icon.Plus />}
        </span>
      </button>
      <div className={`grid transition-all duration-500 ${isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"}`}>
        <div className="overflow-hidden">
          <div className="p-5 lg:p-7 pt-0 lg:pt-0">{children}</div>
        </div>
      </div>
    </div>
  );
}

function Lbl({ k, err }) {
  return (
    <div className="flex items-center justify-between mb-2">
      <label className="field-label">{k}</label>
      {err && <span className="font-mono text-[10px] tracking-[.18em] uppercase text-rose-500">! {err}</span>}
    </div>
  );
}

function ServiceChips({ selected, onToggle }) {
  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-2">
      {SERVICES.map(s => {
        const on = selected.includes(s.id);
        const I = Icon[s.icon] || Icon.Drop;
        return (
          <button key={s.id} type="button" onClick={() => onToggle(s.id)}
            className={`relative p-4 text-left border transition-all ${on ? "bg-blood-500/12 border-blood-500/55" : "bg-ink-800 border-white/10 hover:border-white/25"}`}>
            <div className="flex items-center justify-between">
              <span className={on ? "text-blood-400" : "text-blood-500/70"}><I /></span>
              <span className={`w-4 h-4 border ${on ? "bg-blood-500 border-blood-500" : "border-white/25"} flex items-center justify-center`}>
                {on && <span className="text-ink-900 scale-75"><Icon.Check /></span>}
              </span>
            </div>
            <div className="text-[14px] text-bone mt-3 leading-tight">{s.name}</div>
            <div className="text-[11.5px] text-white/55 mt-1 leading-snug">{s.blurb}</div>
          </button>
        );
      })}
    </div>
  );
}

function SubBlock({ title, sub, children }) {
  return (
    <div className="mt-5 bg-ink-800 border border-white/8 p-4 lg:p-5">
      <div className="flex items-baseline justify-between gap-3 flex-wrap mb-4">
        <h4 className="font-display text-[24px] text-bone leading-tight">{title}</h4>
        <div className="font-mono text-[10px] tracking-[.18em] text-white/45 uppercase">{sub}</div>
      </div>
      {children}
    </div>
  );
}

function DidYouKnow({ text }) {
  return (
    <div className="mt-4 flex items-start gap-3 bg-ink-800 border border-white/8 p-3.5">
      <span className="text-blood-400 mt-0.5"><Icon.Bolt /></span>
      <div>
        <div className="font-mono text-[9.5px] tracking-[.22em] text-blood-400 uppercase">DID YOU KNOW</div>
        <div className="text-[12.5px] text-white/65 mt-0.5 leading-[1.6]">{text}</div>
      </div>
    </div>
  );
}

function SummaryLine({ k, v, price }) {
  return (
    <div className="flex items-start justify-between gap-3 py-1.5 border-b border-white/5 last:border-b-0">
      <div className="min-w-0">
        <div className="font-mono text-[10px] tracking-[.2em] text-white/40 uppercase">{k}</div>
        <div className="text-[13px] text-bone truncate">{v}</div>
      </div>
      {price && <div className="font-mono text-[12px] text-blood-400 whitespace-nowrap">{price}</div>}
    </div>
  );
}

function Submitted({ contact, vehicle, services, detailPkg, ceramicSurfaces, plan, onReset }) {
  return (
    <div className="mt-12 bg-ink-900 border border-white/10 p-8 lg:p-12 text-center">
      <div className="w-16 h-16 bg-blood-500/15 border border-blood-500/40 rounded-full mx-auto flex items-center justify-center text-blood-400">
        <Icon.Check />
      </div>
      <h3 className="font-display text-[44px] text-bone mt-6 leading-none">Build received.</h3>
      <p className="text-white/65 text-[14px] mt-4 max-w-[480px] mx-auto leading-[1.7]">
        Dominick will text <span className="text-blood-400 font-mono">{contact.phone}</span> within the hour during business hours with a firm quote for your {vehicle.year} {vehicle.make} {vehicle.model}.
      </p>

      <div className="mt-7 max-w-[560px] mx-auto text-left bg-ink-700 border border-white/10 p-5">
        <div className="font-mono text-[10px] tracking-[.22em] text-blood-500 uppercase mb-3">// REQUEST SUMMARY</div>
        <SummaryLine k="Vehicle" v={`${vehicle.year} ${vehicle.make} ${vehicle.model}`} />
        {services.includes("detail")    && <SummaryLine k="Detailing"   v={detailPkg ? detailPkg.name : "Auto Detailing — quote on inspection"} />}
        {services.includes("ceramic")   && <SummaryLine k="Ceramic"     v={ceramicSurfaces.length ? ceramicSurfaces.join(", ") : "Custom surfaces"} />}
        {services.includes("plan")      && <SummaryLine k="Maintenance" v={plan ? plan.name : "Plan to be decided"} />}
        {services.includes("biohazard") && <SummaryLine k="Bio-Hazard"  v="Custom inspection — confidential" />}
      </div>

      <div className="mt-7 flex items-center justify-center gap-3 flex-wrap">
        <a href={BUSINESS.phoneHref} className="btn-ghost px-5 py-3 rounded-sm text-[11px] uppercase tracking-[.16em] flex items-center gap-2">
          <Icon.Phone /> Call Now
        </a>
        <button onClick={onReset} className="btn-primary px-5 py-3 rounded-sm text-[11px] uppercase tracking-[.16em]">
          Build Another
        </button>
      </div>
    </div>
  );
}

window.BuildPackageSection = BuildPackageSection;
