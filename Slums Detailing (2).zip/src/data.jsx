/* =====================================================================
   DATA · single source of truth for packages, plans, add-ons, vehicles.
   =================================================================== */

const PACKAGES = [
  // --- DETAILING ----------------------------------------------------
  {
    id: "express-clay-seal",
    category: "detail",
    name: "Express Clay & Seal",
    tagline: "Decontaminate. Seal. Done in under 3 hours.",
    duration: "2–3 hr",
    base: 150,
    pricing: { sedan: 150, suv: 175, truck: 195, motorcycle: 110 },
    summary: "A premium exterior with clay-bar decontamination and a fast 6–8 month sealant. The clean we book most often between full details.",
    includes: [
      "pH-neutral foam pre-soak",
      "2-bucket hand wash · grit-guard method",
      "Wheels, tires, fender wells",
      "Iron-remover · road fallout",
      "Full clay-bar decontamination",
      "8-month spray sealant",
      "Tire dressing · low-sling",
    ],
    badge: null,
  },
  {
    id: "executive-buff-seal",
    category: "detail",
    name: "Executive Buff N Seal",
    tagline: "1-step machine polish + 12-month protection.",
    duration: "4–5 hr",
    base: 349,
    pricing: { sedan: 349, suv: 399, truck: 449, motorcycle: 249 },
    summary: "Removes 60–70% of light swirls and oxidation with a single-stage cut & polish. Finished with a long-life sealant for high-gloss protection through every season.",
    includes: [
      "Everything in Express Clay & Seal",
      "1-step machine polish · DA + foam",
      "Paint depth + finish inspection",
      "Trim & plastic restoration",
      "12-month ceramic sealant",
      "Glass · streak-free with rain-repellant",
    ],
    badge: "MOST POPULAR",
  },
  {
    id: "express-interior",
    category: "detail",
    name: "Express Interior Detail",
    tagline: "Carpets, seats, vents — the daily reset.",
    duration: "2–3 hr",
    base: 159,
    pricing: { sedan: 159, suv: 189, truck: 209, motorcycle: 89 },
    summary: "Vacuum-down to wipe-up, the interior reset for daily drivers. Crumbs, dust, fingerprints, gone.",
    includes: [
      "Full vacuum · carpets + seats + trunk",
      "Air-compressor blow-out · vents + seams",
      "All-surface wipe-down + UV protectant",
      "Floor mat shampoo · spot extraction",
      "Glass · interior, no streaks",
      "Light scent · neutral",
    ],
    badge: null,
  },
  {
    id: "executive-deep-cleaning",
    category: "detail",
    name: "Executive Deep Cleaning",
    tagline: "Hot-extract every fiber. Restore every surface.",
    duration: "5–6 hr",
    base: 299,
    pricing: { sedan: 299, suv: 349, truck: 389, motorcycle: 0 },
    summary: "A full interior restoration: hot-extraction shampoo, leather deep clean + condition, headliner spot treatment, and steam down to the door jambs.",
    includes: [
      "Everything in Express Interior",
      "Hot extraction shampoo · all carpets",
      "Seats · fabric extracted or leather conditioned",
      "Headliner · spot-treated",
      "Steam clean · vents, seams, console",
      "Leather sealant",
    ],
    badge: null,
  },
  {
    id: "express-full",
    category: "detail",
    name: "Express Full Detail",
    tagline: "Inside out. Daily-driver ready.",
    duration: "4–5 hr",
    base: 249,
    pricing: { sedan: 249, suv: 289, truck: 329, motorcycle: 159 },
    summary: "Express Clay & Seal + Express Interior in a single appointment. The best-value full reset for cars that just need to look right again.",
    includes: [
      "Full Express Clay & Seal exterior",
      "Full Express Interior",
      "Door jambs · cleaned & dressed",
      "Tire shine · long-lasting",
      "Wax topcoat · 3 months",
    ],
    badge: null,
  },
  {
    id: "luxury-full",
    category: "detail",
    name: "Luxury Full Detail",
    tagline: "The flagship. Everything we do.",
    duration: "7–9 hr",
    base: 549,
    pricing: { sedan: 549, suv: 629, truck: 699, motorcycle: 0 },
    summary: "Our top-tier full detail. Combines Executive Buff N Seal exterior with Executive Deep Cleaning interior. The car leaves the way it should have left the dealer.",
    includes: [
      "Executive Buff N Seal exterior",
      "Executive Deep Cleaning interior",
      "Engine bay · hand-detailed",
      "Wheel face polish",
      "12-month ceramic sealant",
      "Final inspection · photo report",
    ],
    badge: "FLAGSHIP",
  },

  // --- CERAMIC ------------------------------------------------------
  {
    id: "ceramic-3yr-no-correction",
    category: "ceramic",
    name: "3 Year Ceramic Coating",
    tagline: "No paint correction · for newer or already-polished paint.",
    duration: "1 day",
    base: 799,
    pricing: { sedan: 799, suv: 899, truck: 999, motorcycle: 499 },
    summary: "Professional 3-year ceramic on prepped paint — ideal for cars under 1 year old or freshly polished. Glass-like gloss, real hydrophobicity, no annual sealants.",
    includes: [
      "Full decontamination wash",
      "Iron + tar removal",
      "Panel-by-panel IPA wipedown",
      "3-year Gyeon Mohs ceramic · 1 layer",
      "Wheel face coating",
      "3-year warranty",
    ],
    badge: null,
  },
  {
    id: "ceramic-3yr",
    category: "ceramic",
    name: "3 Year Ceramic Coating",
    tagline: "With 1-step paint correction.",
    duration: "1–2 days",
    base: 1199,
    pricing: { sedan: 1199, suv: 1349, truck: 1499, motorcycle: 749 },
    summary: "Paint corrected to remove 60–70% of swirls + oxidation, then sealed under 3-year Gyeon ceramic. The right tier for daily drivers you plan to keep.",
    includes: [
      "1-step machine polish · DA + foam",
      "Panel-by-panel IPA wipedown",
      "3-year Gyeon Mohs ceramic · 1 layer",
      "Glass coating · windshield + front side",
      "Wheel face + caliper coating",
      "3-year warranty",
    ],
    badge: null,
  },
  {
    id: "ceramic-5yr",
    category: "ceramic",
    name: "5 Year Ceramic Coating",
    tagline: "Multi-stage correction + 2-layer Gyeon Syncro.",
    duration: "2–3 days",
    base: 1899,
    pricing: { sedan: 1899, suv: 2099, truck: 2299, motorcycle: 1199 },
    summary: "The long-game. Two-stage paint correction removes 90%+ of defects, then we lay down Gyeon Syncro: a primer + topcoat system rated for 5 years of gloss and protection.",
    includes: [
      "2-step paint correction · cut + polish",
      "Gyeon Syncro · base + top coat",
      "Full glass coating · all windows",
      "Wheel face + caliper + barrel coating",
      "Plastic trim coating",
      "5-year warranty · annual inspection",
    ],
    badge: "PREMIUM",
  },

  // --- BIO HAZARD ---------------------------------------------------
  {
    id: "bio-hazard",
    category: "biohazard",
    name: "Bio-Hazard Cleaning",
    tagline: "Bodily fluids · animal waste · mold · custom quoted.",
    duration: "Quote on inspection",
    base: 0,
    custom: true,
    pricing: { sedan: 0, suv: 0, truck: 0, motorcycle: 0 },
    summary: "OSHA-aligned cleaning for biohazardous contamination. Pricing is custom because the work and exposure are not.",
    includes: [
      "Full PPE + bloodborne pathogen protocol",
      "Enzymatic + hospital-grade chemistry",
      "Carpet & seat tear-down if needed",
      "Ozone shock · 4–8 hours",
      "Regulated waste disposal · documented",
      "Final ATP swab · pass/fail report",
    ],
    badge: "QUOTE",
  },
];

/* === MAINTENANCE PLANS =============================================== */
const PLANS = [
  { id: "monthly",  name: "Monthly Detail Maintenance",   cadence: "Every 4 weeks",  price: 149, summary: "Wash, interior wipedown, glass. Keeps the car in show shape between full details." },
  { id: "biweekly", name: "Bi-weekly Detail Maintenance", cadence: "Every 2 weeks",  price: 199, summary: "Adds tire dressing, vacuum, and dashboard treatment. Daily-driver insurance." },
  { id: "weekly",   name: "Weekly Detail Maintenance",    cadence: "Every week",     price: 299, summary: "Show-car level. Maintenance polish, interior reset, paint inspection. Concierge tier." },
];

const PREPAY_OPTIONS = [
  { id: "monthly-1",  months: 1,  label: "Pay monthly",     discount: 0 },
  { id: "prepay-3",   months: 3,  label: "Prepay 3 months", discount: 0.10 },
  { id: "prepay-6",   months: 6,  label: "Prepay 6 months", discount: 0.15 },
  { id: "prepay-12",  months: 12, label: "Prepay 1 year",   discount: 0.20 },
];

/* === ADD-ONS ========================================================= */
const ADDONS = [
  { id: "pet-hair",  name: "Pet hair removal",      price: 45,  blurb: "Up to severe. Beyond severe = quoted." },
  { id: "mud",       name: "Mud / heavy soil",      price: 60,  blurb: "Off-road, job-site, or flood-level filth." },
  { id: "ozone",     name: "Ozone odor removal",    price: 85,  blurb: "Smoke, pet, food. 4-hour shock cycle." },
  { id: "headlight", name: "Headlight restoration", price: 89,  blurb: "Wet-sand + polish + UV topcoat. Per pair." },
  { id: "engine",    name: "Engine bay detail",     price: 75,  blurb: "Steam, degrease, dress. Concours-grade." },
  { id: "leather",   name: "Leather conditioner",   price: 35,  blurb: "Deep-feed conditioner + protectant." },
];

/* === VEHICLE TYPES =================================================== */
const VEHICLES = [
  { id: "sedan",      name: "Sedan / Sports Car", icon: "Car",     mult: 1.00 },
  { id: "suv",        name: "SUV / Crossover",    icon: "Suv",     mult: 1.15 },
  { id: "truck",      name: "Truck",              icon: "Truck",   mult: 1.30 },
  { id: "motorcycle", name: "Motorcycle",         icon: "Moto",    mult: 0.70 },
];

/* === SERVICE CATEGORIES (main 4) ====================================== */
const SERVICES = [
  { id: "detail",    name: "Auto Detailing",      slug: "auto-detailing", icon: "Drop",   blurb: "Interior, exterior, and full details — daily drivers to showroom resets." },
  { id: "ceramic",   name: "Ceramic Coating",     slug: "ceramic",        icon: "Shield", blurb: "3-year and 5-year Gyeon-certified ceramic with proper paint prep." },
  { id: "plan",      name: "Maintenance Program", slug: "maintenance",    icon: "Cycle",  blurb: "Weekly, bi-weekly, monthly plans · prepay 20% off." },
  { id: "biohazard", name: "Bio-Hazard Cleaning", slug: "bio-hazard",     icon: "Hazard", blurb: "OSHA-aligned cleaning for bodily fluids, mold, animal waste." },
];

/* === BUSINESS INFO =================================================== */
const BUSINESS = {
  name: "Slums Detailing",
  city: "Martinsburg",
  state: "WV",
  phone: "(304) 555-0199",
  phoneHref: "tel:+13045550199",
  email: "hello@slumsdetailing.com",
  ig: "https://instagram.com/slumsdetailing",
  tt: "https://tiktok.com/@slumsdetailing",
  fb: "https://facebook.com/slumsdetailing",
  hours: [
    ["Monday",  "9:00 AM — 5:00 PM"],
    ["Tue–Sat", "8:00 AM — 6:00 PM"],
    ["Sunday",  "Closed"],
  ],
  radius: "90 minutes of Martinsburg, WV",
};

Object.assign(window, { PACKAGES, PLANS, PREPAY_OPTIONS, ADDONS, VEHICLES, SERVICES, BUSINESS });
