/* =====================================================================
   SERVICE AREAS PAGE
   ===================================================================
   Inspired layout: hero with reach statement → state-grouped city grid
   with distance/drive-time chips → coverage stats → "don't see your
   city?" CTA → build-package at bottom.
   =================================================================== */

const SERVICE_AREAS = {
  "West Virginia": [
    { city: "Martinsburg",      county: "Berkeley",   drive: "Home base", distance: "0 mi",   primary: true,  zip: "25401–25405" },
    { city: "Hedgesville",      county: "Berkeley",   drive: "15 min",    distance: "8 mi",   primary: true,  zip: "25427" },
    { city: "Inwood",           county: "Berkeley",   drive: "18 min",    distance: "11 mi",  primary: true,  zip: "25428" },
    { city: "Falling Waters",   county: "Berkeley",   drive: "15 min",    distance: "9 mi",   primary: true,  zip: "25419" },
    { city: "Bunker Hill",      county: "Berkeley",   drive: "22 min",    distance: "14 mi",  primary: false, zip: "25413" },
    { city: "Kearneysville",    county: "Jefferson",  drive: "22 min",    distance: "13 mi",  primary: false, zip: "25430" },
    { city: "Shepherdstown",    county: "Jefferson",  drive: "28 min",    distance: "18 mi",  primary: false, zip: "25443" },
    { city: "Charles Town",     county: "Jefferson",  drive: "30 min",    distance: "20 mi",  primary: true,  zip: "25414" },
    { city: "Ranson",           county: "Jefferson",  drive: "30 min",    distance: "20 mi",  primary: false, zip: "25438" },
    { city: "Harpers Ferry",    county: "Jefferson",  drive: "36 min",    distance: "25 mi",  primary: false, zip: "25425" },
    { city: "Berkeley Springs", county: "Morgan",     drive: "40 min",    distance: "28 mi",  primary: false, zip: "25411" },
    { city: "Keyser",           county: "Mineral",    drive: "1 h 25 min",distance: "82 mi",  primary: false, zip: "26726" },
  ],
  "Maryland": [
    { city: "Hagerstown",       county: "Washington", drive: "25 min",    distance: "20 mi",  primary: true,  zip: "21740" },
    { city: "Williamsport",     county: "Washington", drive: "22 min",    distance: "15 mi",  primary: false, zip: "21795" },
    { city: "Sharpsburg",       county: "Washington", drive: "30 min",    distance: "20 mi",  primary: false, zip: "21782" },
    { city: "Boonsboro",        county: "Washington", drive: "35 min",    distance: "25 mi",  primary: false, zip: "21713" },
    { city: "Smithsburg",       county: "Washington", drive: "40 min",    distance: "28 mi",  primary: false, zip: "21783" },
    { city: "Frederick",        county: "Frederick",  drive: "50 min",    distance: "40 mi",  primary: false, zip: "21701–21705" },
    { city: "Middletown",       county: "Frederick",  drive: "45 min",    distance: "32 mi",  primary: false, zip: "21769" },
    { city: "Cumberland",       county: "Allegany",   drive: "1 h 20 min",distance: "80 mi",  primary: false, zip: "21502" },
  ],
  "Virginia": [
    { city: "Winchester",       county: "Frederick",  drive: "40 min",    distance: "30 mi",  primary: true,  zip: "22601–22604" },
    { city: "Stephens City",    county: "Frederick",  drive: "45 min",    distance: "34 mi",  primary: false, zip: "22655" },
    { city: "Berryville",       county: "Clarke",     drive: "45 min",    distance: "32 mi",  primary: false, zip: "22611" },
    { city: "Front Royal",      county: "Warren",     drive: "1 h 5 min", distance: "50 mi",  primary: false, zip: "22630" },
    { city: "Strasburg",        county: "Shenandoah", drive: "1 h 10 min",distance: "55 mi",  primary: false, zip: "22657" },
    { city: "Leesburg",         county: "Loudoun",    drive: "55 min",    distance: "42 mi",  primary: false, zip: "20175–20178" },
    { city: "Purcellville",     county: "Loudoun",    drive: "45 min",    distance: "34 mi",  primary: false, zip: "20132" },
    { city: "Round Hill",       county: "Loudoun",    drive: "45 min",    distance: "32 mi",  primary: false, zip: "20141" },
  ],
};

function ServiceAreasPage({ onInquiry, onNav }) {
  const [activeState, setActiveState] = React.useState("All");
  const [query, setQuery] = React.useState("");

  const states = ["All", ...Object.keys(SERVICE_AREAS)];

  const allCities = Object.entries(SERVICE_AREAS).flatMap(([state, cities]) =>
    cities.map(c => ({ ...c, state }))
  );

  const filtered = allCities.filter(c => {
    if (activeState !== "All" && c.state !== activeState) return false;
    if (query.trim() && !`${c.city} ${c.county} ${c.zip} ${c.state}`.toLowerCase().includes(query.toLowerCase())) return false;
    return true;
  });

  const groupedFiltered = Object.entries(SERVICE_AREAS).reduce((acc, [state, cities]) => {
    const list = cities.filter(c => {
      if (activeState !== "All" && state !== activeState) return false;
      if (query.trim() && !`${c.city} ${c.county} ${c.zip} ${state}`.toLowerCase().includes(query.toLowerCase())) return false;
      return true;
    });
    if (list.length) acc[state] = list;
    return acc;
  }, {});

  const primaryCount = allCities.filter(c => c.primary).length;
  const totalCities  = allCities.length;

  return (
    <>
      <AreasHero totalCities={totalCities} primaryCount={primaryCount} />
      <TrustBar />
      <AreasCoverage />

      <section className="relative bg-ink-900 py-20 lg:py-28">
        <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
          <SectionHeader
            eyebrow="// 02 — CITY DIRECTORY"
            title={<>Every city we<br/><span className="text-blood-500">currently serve</span>.</>}
            right="Live list. If your city isn't here but is within 90 minutes of Martinsburg, ask — we book outside this list weekly. We just don't promise same-week scheduling on it."
          />

          {/* filters */}
          <div className="mt-10 grid sm:grid-cols-12 gap-3 items-center">
            <div className="sm:col-span-7">
              <div className="flex gap-2 flex-wrap">
                {states.map(s => {
                  const on = activeState === s;
                  return (
                    <button key={s} onClick={() => setActiveState(s)}
                      className={`px-4 py-2.5 font-mono text-[10.5px] tracking-[.2em] uppercase border transition-all
                        ${on ? "bg-blood-500 text-ink-900 border-blood-500" : "border-white/10 text-white/65 hover:border-blood-500/40 hover:text-bone"}`}>
                      {s}
                    </button>
                  );
                })}
              </div>
            </div>
            <div className="sm:col-span-5">
              <div className="relative">
                <input value={query} onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search city, county, zip…"
                  className="field pr-10 text-[13px]" />
                {query && (
                  <button onClick={() => setQuery("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-white/45 hover:text-rose-500" aria-label="Clear">
                    <Icon.Close />
                  </button>
                )}
              </div>
            </div>
          </div>

          <div className="mt-5 font-mono text-[10.5px] tracking-[.2em] text-white/45 uppercase">
            Showing <span className="text-bone">{filtered.length}</span> of {totalCities} cities · primary service area marked <span className="text-blood-400">▲</span>
          </div>

          {/* grouped grid */}
          <div className="mt-8 space-y-12">
            {Object.entries(groupedFiltered).map(([state, cities]) => (
              <StateGroup key={state} state={state} cities={cities} onInquiry={() => onInquiry({})} />
            ))}
            {Object.keys(groupedFiltered).length === 0 && (
              <div className="bg-ink-800 border border-white/8 p-10 text-center">
                <div className="font-display text-[28px] text-bone">No matches in this filter.</div>
                <p className="mt-2 text-white/55 text-[13.5px]">Clear filters or call us — we may still service your area on a case-by-case basis.</p>
              </div>
            )}
          </div>
        </div>
      </section>

      <AreasOutsideRadius onInquiry={onInquiry} />
      <BuildPackageSection id="build-areas" />
    </>
  );
}

/* ============================================================ */
/* HERO                                                         */
/* ============================================================ */
function AreasHero({ totalCities, primaryCount }) {
  return (
    <section className="relative pt-[120px] pb-16 lg:pb-20 overflow-hidden grain">
      <div className="halo absolute inset-0 pointer-events-none"></div>
      <div className="relative max-w-[1480px] mx-auto px-5 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10 items-end">
          <div className="lg:col-span-7">
            <div className="font-mono text-[11px] tracking-[.22em] text-blood-500 uppercase mb-5">// SERVICE AREAS · 90-MIN RADIUS</div>
            <h1 className="font-display text-[56px] sm:text-[80px] lg:text-[112px] leading-[0.88] tracking-[-0.01em] text-bone text-balance">
              We come to you<span className="text-blood-500">.</span><br/>
              Anywhere<br/>
              <span className="text-blood-500">within 90 min</span>.
            </h1>
            <p className="mt-6 max-w-[600px] text-white/65 text-[15px] leading-[1.7] text-pretty">
              Slums Detailing is based in Martinsburg, West Virginia. We service three states from one truck — driveway details across the Eastern Panhandle, Western Maryland, and the Shenandoah Valley.
            </p>

            <div className="mt-10 grid grid-cols-3 gap-4 max-w-[580px]">
              {[
                [`${totalCities}+`, "Cities currently served"],
                [`${primaryCount}`, "Primary same-week areas"],
                ["3", "States · WV · MD · VA"],
              ].map(([n, l]) => (
                <div key={l} className="border-l border-white/10 pl-4">
                  <div className="font-display text-[36px] lg:text-[44px] text-bone leading-none">{n}</div>
                  <div className="font-mono text-[10px] tracking-[.18em] text-white/45 uppercase mt-2 leading-snug">{l}</div>
                </div>
              ))}
            </div>
          </div>

          {/* schematic radius map */}
          <div className="lg:col-span-5 relative">
            <RadiusMap />
          </div>
        </div>
      </div>
    </section>
  );
}

/* ============================================================ */
/* RADIUS MAP · stylized SVG, not a real map                    */
/* ============================================================ */
function RadiusMap() {
  return (
    <div className="relative bg-ink-700 border border-white/8 p-6 aspect-square">
      <div className="font-mono text-[10px] tracking-[.22em] text-blood-500 uppercase">// SERVICE RADIUS · SCHEMATIC</div>

      <svg viewBox="0 0 400 400" className="w-full h-full mt-2" aria-hidden="true">
        {/* grid */}
        <defs>
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M40 0 L0 0 0 40" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="1"/>
          </pattern>
          <radialGradient id="rad-glow" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0%" stopColor="rgba(127,190,255,.25)"/>
            <stop offset="70%" stopColor="rgba(127,190,255,.04)"/>
            <stop offset="100%" stopColor="rgba(127,190,255,0)"/>
          </radialGradient>
        </defs>
        <rect width="400" height="400" fill="url(#grid)"/>

        {/* 90-min outer ring */}
        <circle cx="200" cy="200" r="180" fill="url(#rad-glow)" />
        <circle cx="200" cy="200" r="180" fill="none" stroke="#7FBEFF" strokeWidth="1.2" strokeDasharray="4 6" />
        {/* 45-min inner ring */}
        <circle cx="200" cy="200" r="100" fill="none" stroke="#7FBEFF" strokeWidth="1" strokeDasharray="2 4" opacity="0.5" />
        {/* 15-min core */}
        <circle cx="200" cy="200" r="35" fill="rgba(255,79,139,.18)" stroke="#FF4F8B" strokeWidth="1.4"/>

        {/* HQ pin */}
        <circle cx="200" cy="200" r="5" fill="#FF4F8B"/>

        {/* labels */}
        <text x="200" y="184" textAnchor="middle" fontFamily="JetBrains Mono, monospace" fontSize="10" fill="#FF4F8B" letterSpacing="2">HQ</text>
        <text x="200" y="170" textAnchor="middle" fontFamily="JetBrains Mono, monospace" fontSize="8" fill="rgba(255,255,255,0.55)" letterSpacing="2">MARTINSBURG · WV</text>

        {/* sample city pins */}
        {[
          ["Hagerstown",     270, 145],
          ["Winchester",     265, 280],
          ["Charles Town",   285, 220],
          ["Hedgesville",    165, 150],
          ["Inwood",         210, 255],
          ["Frederick",      350, 175],
          ["Leesburg",       355, 270],
          ["Front Royal",    240, 350],
        ].map(([name, x, y]) => (
          <g key={name}>
            <circle cx={x} cy={y} r="3" fill="#7FBEFF"/>
            <text x={x + 7} y={y + 4} fontFamily="JetBrains Mono, monospace" fontSize="9" fill="rgba(244,245,247,0.7)" letterSpacing="1">{name}</text>
          </g>
        ))}

        {/* axis ticks */}
        <text x="200" y="395" textAnchor="middle" fontFamily="JetBrains Mono, monospace" fontSize="8" fill="rgba(255,255,255,0.35)" letterSpacing="3">SOUTH</text>
        <text x="200" y="14"  textAnchor="middle" fontFamily="JetBrains Mono, monospace" fontSize="8" fill="rgba(255,255,255,0.35)" letterSpacing="3">NORTH</text>
        <text x="6" y="204" fontFamily="JetBrains Mono, monospace" fontSize="8" fill="rgba(255,255,255,0.35)" letterSpacing="3">W</text>
        <text x="386" y="204" fontFamily="JetBrains Mono, monospace" fontSize="8" fill="rgba(255,255,255,0.35)" letterSpacing="3">E</text>
      </svg>

      <div className="absolute bottom-4 left-6 right-6 flex justify-between font-mono text-[9.5px] tracking-[.2em] text-white/45 uppercase">
        <span><span className="text-rose-500">●</span> 15 min · primary</span>
        <span><span className="text-blood-500">●</span> 45 min</span>
        <span><span className="text-blood-500">◌</span> 90 min · outer</span>
      </div>
    </div>
  );
}

/* ============================================================ */
/* COVERAGE STATS                                               */
/* ============================================================ */
function AreasCoverage() {
  const items = [
    { stat: "15 min", label: "Same-day windows", body: "Martinsburg, Hedgesville, Inwood, Falling Waters — book as late as morning-of." },
    { stat: "45 min", label: "Same-week scheduling", body: "Charles Town, Shepherdstown, Hagerstown, Winchester — usually within 3–5 days." },
    { stat: "90 min", label: "Custom routing", body: "Frederick MD, Leesburg VA, Cumberland MD — we batch into trip days, typically Tuesday or Thursday." },
    { stat: "$0",     label: "Travel fee · standard zone", body: "We don't charge travel inside the 90-minute radius. Beyond that is quoted." },
  ];
  return (
    <section className="relative bg-ink-800 py-20 lg:py-24">
      <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
        <SectionHeader
          eyebrow="// 01 — COVERAGE TIERS"
          title={<>How far we go,<br/>and how <span className="text-blood-500">fast</span>.</>}
        />
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mt-12">
          {items.map(it => (
            <div key={it.label} className="bg-ink-700 border border-white/8 p-7">
              <div className="font-display text-[52px] lg:text-[64px] text-blood-500 leading-none">{it.stat}</div>
              <div className="font-mono text-[10px] tracking-[.22em] text-white/45 uppercase mt-3">{it.label}</div>
              <p className="mt-3 text-white/65 text-[13px] leading-[1.65]">{it.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============================================================ */
/* STATE GROUP                                                  */
/* ============================================================ */
function StateGroup({ state, cities, onInquiry }) {
  return (
    <div>
      <div className="flex items-baseline justify-between mb-5 flex-wrap gap-2">
        <div className="flex items-baseline gap-4">
          <span className="font-mono text-[10px] tracking-[.22em] text-blood-500 uppercase">{state}</span>
          <h3 className="font-display text-[36px] lg:text-[44px] text-bone leading-none">
            {cities.length} {cities.length === 1 ? "city" : "cities"}
          </h3>
        </div>
        <div className="font-mono text-[10.5px] tracking-[.2em] text-white/45 uppercase">
          {cities.filter(c => c.primary).length} primary · {cities.filter(c => !c.primary).length} extended
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {cities.map(c => (
          <button key={c.city + c.county} onClick={onInquiry}
            className={`text-left p-5 border transition-all group hover:bg-ink-700
              ${c.primary ? "bg-ink-800 border-white/12 hover:border-blood-500/45" : "bg-ink-900 border-white/8 hover:border-white/20"}`}>
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  {c.primary && <span className="text-blood-400 text-[10px]">▲</span>}
                  <div className="font-display text-[26px] text-bone leading-none">{c.city}</div>
                </div>
                <div className="text-[12px] text-white/55 mt-1">{c.county} County</div>
              </div>
              <div className="text-right whitespace-nowrap">
                <div className="font-mono text-[10px] tracking-[.2em] text-blood-400 uppercase">{c.drive}</div>
                <div className="font-mono text-[10.5px] text-white/45 mt-0.5">{c.distance}</div>
              </div>
            </div>
            <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between font-mono text-[10px] tracking-[.18em] text-white/40 uppercase">
              <span>ZIP {c.zip}</span>
              <span className="flex items-center gap-1 text-bone group-hover:text-blood-400 transition-colors">Quote <Icon.Arrow /></span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ============================================================ */
/* OUTSIDE RADIUS CTA                                           */
/* ============================================================ */
function AreasOutsideRadius({ onInquiry }) {
  return (
    <section className="relative bg-ink-900 py-20 lg:py-24 overflow-hidden">
      <div className="absolute inset-0 halo opacity-50 pointer-events-none"></div>
      <div className="relative max-w-[1480px] mx-auto px-5 lg:px-10">
        <div className="bg-ink-700 border border-white/10 p-8 lg:p-12 grid lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-8">
            <div className="font-mono text-[11px] tracking-[.22em] text-blood-500 uppercase mb-4">// OUTSIDE THE RADIUS?</div>
            <h3 className="font-display text-[36px] lg:text-[56px] leading-[0.95] text-bone">
              We still take the call.<br/>
              <span className="text-blood-500">It just costs a little more.</span>
            </h3>
            <p className="mt-4 text-white/65 text-[14px] leading-[1.7] max-w-[640px]">
              For ceramic coatings and luxury full details outside the 90-minute zone we add a flat travel fee (typically $1.50/mile beyond 90 minutes, capped). Daily detailing usually doesn't pencil out further than that — but ask. Worst case we recommend a local detailer we trust.
            </p>
          </div>
          <div className="lg:col-span-4 flex flex-col gap-3">
            <button onClick={() => onInquiry({})}
              className="btn-primary px-6 py-4 rounded-sm text-[12px] uppercase tracking-[.16em] flex items-center justify-center gap-3">
              Ask About Your City <Icon.Arrow />
            </button>
            <a href={BUSINESS.phoneHref} className="btn-ghost px-6 py-4 rounded-sm text-[12px] uppercase tracking-[.16em] flex items-center justify-center gap-3">
              <Icon.Phone /> {BUSINESS.phone}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

window.ServiceAreasPage = ServiceAreasPage;
