/* =====================================================================
   SHARED COMPONENTS · Nav, Footer, SectionHeader, etc.
   (Placeholder lives in src/placeholders.jsx — editable image-slot version)
   =================================================================== */

/* ---------- Section Header ---------------------------------------- */
function SectionHeader({ eyebrow, title, right, align = "left" }) {
  return (
    <div className={`grid lg:grid-cols-12 gap-8 items-end ${align === "center" ? "text-center" : ""}`}>
      <div className={`lg:col-span-7 ${align === "center" ? "lg:col-start-4 text-center" : ""}`}>
        <div className="font-mono text-[11px] tracking-[.22em] text-blood-500 uppercase mb-5">{eyebrow}</div>
        <h2 className="font-display text-[44px] sm:text-[64px] lg:text-[88px] leading-[0.9] tracking-[-0.01em] text-bone text-balance">{title}</h2>
      </div>
      {right && (
        <div className="lg:col-span-4 lg:col-start-9">
          <p className="text-white/60 text-[14.5px] leading-[1.7] border-l border-white/10 pl-5 text-pretty">{right}</p>
        </div>
      )}
    </div>
  );
}
window.SectionHeader = SectionHeader;

/* ---------- NAV ---------------------------------------------------- */
function Nav({ page, onNav, onInquiry }) {
  const [scrolled, setScrolled] = React.useState(false);
  const [open, setOpen] = React.useState(false);
  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const items = [
    ["Home", "home"],
    ["Auto Detailing", "auto-detailing"],
    ["Ceramic", "ceramic"],
    ["Maintenance", "maintenance"],
    ["Bio-Hazard", "bio-hazard"],
    ["Fleet", "fleet"],
    ["Service Areas", "service-areas"],
  ];

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all ${scrolled || open ? "bg-ink-900/90 backdrop-blur-md border-b border-white/5" : "bg-transparent"}`}>
      <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
        <div className="flex items-center justify-between h-[72px]">
          <button onClick={() => onNav("home")} className="flex items-center gap-3 text-bone group" aria-label="Slums Detailing home">
            <span className="text-blood-500 group-hover:text-blood-400 transition-colors"><Icon.Logo /></span>
            <span className="leading-none text-left">
              <span className="block font-display text-[22px] tracking-[.08em] leading-none">SLUMS</span>
              <span className="block font-mono text-[9px] tracking-[.3em] text-white/45 mt-1">DETAILING · WV</span>
            </span>
          </button>

          <nav className="hidden xl:flex items-center gap-1" aria-label="Primary">
            {items.map(([label, p]) => {
              const active = page === p;
              return (
                <button key={p} onClick={() => onNav(p)}
                  className={`px-3 py-2 text-[12.5px] font-medium transition-colors relative group ${active ? "text-blood-500" : "text-white/75 hover:text-blood-500"}`}>
                  {label}
                  <span className={`absolute left-3 right-3 -bottom-0.5 h-px bg-blood-500 transition-transform origin-left ${active ? "scale-x-100" : "scale-x-0 group-hover:scale-x-100"}`}></span>
                </button>
              );
            })}
          </nav>

          <div className="hidden lg:flex items-center gap-3">
            <a href={BUSINESS.phoneHref} className="flex items-center gap-2 text-[12.5px] text-white/80 hover:text-blood-500 transition-colors">
              <Icon.Phone /> <span className="font-mono">{BUSINESS.phone}</span>
            </a>
            <button onClick={onInquiry} className="btn-primary px-5 py-2.5 rounded-sm text-[12px] uppercase tracking-[.14em] flex items-center gap-2">
              Get Quote <Icon.Arrow />
            </button>
          </div>

          <button onClick={() => setOpen(!open)} className="xl:hidden p-2 text-bone" aria-label="Menu" aria-expanded={open}>
            {open ? <Icon.Close /> : <Icon.Menu />}
          </button>
        </div>

        {open && (
          <div className="xl:hidden pb-6 border-t border-white/5 pt-3">
            <div className="flex flex-col">
              {items.map(([label, p]) => (
                <button key={p} onClick={() => { setOpen(false); onNav(p); }}
                  className={`text-left px-3 py-3.5 border-b border-white/5 text-sm ${page === p ? "text-blood-500" : "text-bone/85"}`}>
                  {label}
                </button>
              ))}
              <button onClick={() => { setOpen(false); onInquiry(); }} className="btn-primary mt-4 px-5 py-3.5 rounded-sm text-xs uppercase tracking-[.14em] inline-flex items-center justify-center gap-2">
                Get Quote <Icon.Arrow />
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
window.Nav = Nav;

/* ---------- MARQUEE ----------------------------------------------- */
function Marquee() {
  const items = [
    "GYEON CERTIFIED",
    "PAINT CORRECTION",
    "★ 4.98 · 214 REVIEWS",
    "GYEON · KOCH-CHEMIE · SUPERIOR PRODUCTS",
    "MOBILE · WE COME TO YOU",
    "MARTINSBURG · HEDGESVILLE · INWOOD · CHARLES TOWN",
    "WV · MD · VA · 90 MIN RADIUS",
    "BOOK 24/7",
  ];
  const loop = [...items, ...items];
  return (
    <div className="relative border-y border-white/8 py-5 overflow-hidden bg-ink-900" aria-hidden="true">
      <div className="marquee-track flex whitespace-nowrap gap-12">
        {loop.map((t, i) => (
          <span key={i} className="font-display text-[26px] tracking-[.1em] text-white/55 flex items-center gap-12">
            {t}<span className="text-blood-500">✦</span>
          </span>
        ))}
      </div>
      <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-ink-900 to-transparent pointer-events-none"></div>
      <div className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-ink-900 to-transparent pointer-events-none"></div>
    </div>
  );
}
window.Marquee = Marquee;

/* ---------- CTA STRIP --------------------------------------------- */
function CTAStrip({ onInquiry, title, sub }) {
  return (
    <section className="relative bg-ink-900 py-20 lg:py-24 overflow-hidden">
      <div className="absolute inset-0 halo pointer-events-none"></div>
      <div className="relative max-w-[1480px] mx-auto px-5 lg:px-10">
        <div className="border border-white/10 bg-ink-700 p-8 lg:p-12 relative overflow-hidden">
          <div className="absolute top-0 right-0 bottom-0 w-1/2 stripe-blood opacity-30 pointer-events-none"></div>
          <div className="relative grid lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-8">
              <div className="font-mono text-[11px] tracking-[.22em] text-blood-500 uppercase mb-4">// READY?</div>
              <h3 className="font-display text-[40px] lg:text-[64px] leading-[0.95] text-bone text-balance">
                {title || <>Park it in your driveway.<br/><span className="text-blood-500">We'll handle the rest.</span></>}
              </h3>
              {sub && <p className="mt-4 text-white/65 text-[14.5px] leading-[1.7] max-w-[520px]">{sub}</p>}
            </div>
            <div className="lg:col-span-4 flex flex-col gap-3">
              <button onClick={onInquiry} className="btn-primary px-6 py-4 rounded-sm text-[12px] uppercase tracking-[.16em] flex items-center justify-center gap-3">
                Get a Quote <Icon.Arrow />
              </button>
              <a href={BUSINESS.phoneHref} className="btn-ghost px-6 py-4 rounded-sm text-[12px] uppercase tracking-[.16em] flex items-center justify-center gap-3">
                <Icon.Phone /> {BUSINESS.phone}
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
window.CTAStrip = CTAStrip;

/* ---------- FOOTER ------------------------------------------------ */
function Footer({ onNav }) {
  return (
    <footer className="relative bg-ink-900 border-t border-white/8 pt-16 pb-10 overflow-hidden">
      <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10 lg:gap-8 pb-14">
          <div className="lg:col-span-4">
            <button onClick={() => onNav("home")} className="flex items-center gap-3 text-bone">
              <span className="text-blood-500"><Icon.Logo /></span>
              <span className="text-left">
                <span className="block font-display text-[24px] tracking-[.08em] leading-none">SLUMS DETAILING</span>
                <span className="block font-mono text-[9px] tracking-[.3em] text-white/45 mt-1">EST · 2021 · MARTINSBURG WV</span>
              </span>
            </button>
            <p className="mt-6 text-white/55 text-[13.5px] leading-[1.7] max-w-[360px]">
              Owner-operated mobile auto detailing serving Martinsburg, Hedgesville, Inwood, Falling Waters, Charles Town, and within 90 minutes of Martinsburg, WV.
            </p>
            <div className="mt-6 flex items-center gap-2">
              <a href={BUSINESS.ig} target="_blank" rel="noopener noreferrer" className="w-10 h-10 border border-white/10 flex items-center justify-center text-white/65 hover:text-blood-500 hover:border-blood-500/40 transition-colors" aria-label="Instagram"><Icon.Instagram /></a>
              <a href={BUSINESS.tt} target="_blank" rel="noopener noreferrer" className="w-10 h-10 border border-white/10 flex items-center justify-center text-white/65 hover:text-blood-500 hover:border-blood-500/40 transition-colors" aria-label="TikTok"><Icon.Tiktok /></a>
              <a href={BUSINESS.fb} target="_blank" rel="noopener noreferrer" className="w-10 h-10 border border-white/10 flex items-center justify-center text-white/65 hover:text-blood-500 hover:border-blood-500/40 transition-colors" aria-label="Facebook"><Icon.Facebook /></a>
              <span className="font-mono text-[10px] tracking-[.2em] text-white/40 uppercase ml-2">@slumsdetailing</span>
            </div>
          </div>

          <FooterCol title="Services">
            <FooterLink onClick={() => onNav("auto-detailing")}>Auto Detailing</FooterLink>
            <FooterLink onClick={() => onNav("ceramic")}>Ceramic Coating</FooterLink>
            <FooterLink onClick={() => onNav("maintenance")}>Maintenance Programs</FooterLink>
            <FooterLink onClick={() => onNav("bio-hazard")}>Bio-Hazard Cleaning</FooterLink>
            <FooterLink onClick={() => onNav("fleet")}>Fleet Detailing</FooterLink>
            <FooterLink onClick={() => onNav("service-areas")}>Service Areas</FooterLink>
          </FooterCol>

          <FooterCol title="Hours">
            {BUSINESS.hours.map(([d, h]) => (
              <div key={d} className="flex justify-between gap-3 text-[13px] text-white/65">
                <span>{d}</span>
                <span className="font-mono text-[11.5px] text-white/75">{h}</span>
              </div>
            ))}
            <div className="mt-3 font-mono text-[10px] tracking-[.2em] text-blood-400 uppercase">Mobile · 90-min radius</div>
          </FooterCol>

          <FooterCol title="Contact">
            <a href={BUSINESS.phoneHref} className="text-[13px] text-white/65 hover:text-blood-500 flex items-center gap-2"><Icon.Phone /> {BUSINESS.phone}</a>
            <a href={`mailto:${BUSINESS.email}`} className="text-[13px] text-white/65 hover:text-blood-500 flex items-center gap-2 break-all"><Icon.Mail /> {BUSINESS.email}</a>
            <div className="flex items-center gap-2 text-[13px] text-white/65"><Icon.Pin /> Martinsburg, WV</div>
            <div className="font-mono text-[11px] text-white/45 leading-[1.7] mt-3">WV-DTL-0418 · INS-2026</div>
          </FooterCol>
        </div>

        <div className="border-t border-white/5 pt-8 pb-4 overflow-hidden">
          <div className="font-display text-[clamp(70px,17vw,260px)] leading-[0.85] text-bone tracking-[-0.02em] whitespace-nowrap">
            SLUMS<span className="text-blood-500">/</span>DETAILING<span className="text-blood-500">.</span>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 pt-6 border-t border-white/5 font-mono text-[10px] tracking-[.2em] text-white/40 uppercase">
          <div>© 2026 SLUMS DETAILING LLC · MARTINSBURG WV</div>
          <div className="flex items-center gap-4">
            <button onClick={() => onNav("home")} className="hover:text-blood-500">HOME</button>
            <span className="opacity-30">/</span>
            <button onClick={() => onNav("service-areas")} className="hover:text-blood-500">AREAS</button>
            <span className="opacity-30">/</span>
            <a href={`mailto:${BUSINESS.email}`} className="hover:text-blood-500">EMAIL</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

function FooterCol({ title, children }) {
  return (
    <div className="lg:col-span-2 lg:[&:nth-child(4)]:col-span-3">
      <div className="font-mono text-[10px] tracking-[.24em] text-blood-500 uppercase mb-5">// {title}</div>
      <div className="flex flex-col gap-2.5">{children}</div>
    </div>
  );
}

function FooterLink({ onClick, children }) {
  return <button onClick={onClick} className="text-[13px] text-left text-white/65 hover:text-bone transition-colors">{children}</button>;
}
window.Footer = Footer;

/* ---------- DISCLAIMER BANNER ------------------------------------- */
function ConditionDisclaimer({ className = "" }) {
  return (
    <div className={`flex items-start gap-3 bg-blood-500/8 border border-blood-500/25 text-blood-300 p-4 ${className}`}>
      <span className="mt-0.5 flex-shrink-0"><Icon.Warning /></span>
      <p className="text-[12.5px] leading-[1.6]">
        <span className="font-semibold text-blood-400">Pricing note · </span>
        Prices listed assume normal soiling. Heavy dog hair, mud, sticky residue, food spills, biohazards, or extreme oxidation will be quoted higher. We'll confirm any upcharge before any work begins.
      </p>
    </div>
  );
}
window.ConditionDisclaimer = ConditionDisclaimer;

/* ---------- TRUST BAR --------------------------------------------- */
function TrustBar() {
  const items = [
    { icon: "Truck",   label: "We Come To You" },
    { icon: "Shield",  label: "Gyeon-Certified Ceramic" },
    { icon: "Clock",   label: "Mon 9–5 · Tue–Sat 8–6" },
    { icon: "Pin",     label: "Martinsburg + 90 min" },
    { icon: "Star",    label: "4.98 · 214 reviews" },
  ];
  return (
    <div className="bg-ink-800 border-y border-white/5">
      <div className="max-w-[1480px] mx-auto px-5 lg:px-10 py-5 flex flex-wrap items-center justify-center gap-x-10 gap-y-3">
        {items.map((it, i) => {
          const I = Icon[it.icon] || Icon.Star;
          return (
            <div key={i} className="flex items-center gap-2.5 text-[12.5px] text-white/70">
              <span className="text-blood-500"><I /></span>
              <span className="font-medium">{it.label}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
window.TrustBar = TrustBar;
