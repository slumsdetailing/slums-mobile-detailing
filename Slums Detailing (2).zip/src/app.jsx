/* =====================================================================
   APP · hash-based router + global inquiry modal
   =================================================================== */

const ROUTES = ["home", "auto-detailing", "ceramic", "maintenance", "bio-hazard", "fleet", "service-areas"];

function App() {
  const [page, setPage] = React.useState(() => {
    const h = (window.location.hash || "").replace("#/", "").replace("#", "");
    return ROUTES.includes(h) ? h : "home";
  });

  // inquiry state — can be opened with seeded fields
  const [inquiry, setInquiry] = React.useState({ open: false, service: null, package: null, vehicle: null });
  const openInquiry  = (seed = {}) => setInquiry({ open: true, service: seed.service || null, package: seed.package || null, vehicle: seed.vehicle || null });
  const closeInquiry = () => setInquiry(i => ({ ...i, open: false }));

  // navigation
  const navigate = (to) => {
    if (!ROUTES.includes(to)) to = "home";
    setPage(to);
    window.location.hash = "/" + to;
    window.scrollTo({ top: 0, behavior: "instant" });
  };

  // listen to back/forward
  React.useEffect(() => {
    const onHash = () => {
      const h = (window.location.hash || "").replace("#/", "").replace("#", "");
      if (ROUTES.includes(h)) setPage(h);
      else if (!h) setPage("home");
    };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  return (
    <>
      <Nav page={page} onNav={navigate} onInquiry={() => openInquiry()} />

      <main data-screen-label={page}>
        {page === "home"            && <Home            onNav={navigate} onInquiry={() => openInquiry()} />}
        {page === "auto-detailing"  && <AutoDetailingPage onInquiry={openInquiry} onNav={navigate} />}
        {page === "ceramic"         && <CeramicPage      onInquiry={openInquiry} onNav={navigate} />}
        {page === "maintenance"     && <MaintenancePage  onInquiry={openInquiry} />}
        {page === "bio-hazard"      && <BioHazardPage    onInquiry={openInquiry} />}
        {page === "fleet"           && <FleetPage        onInquiry={openInquiry} onNav={navigate} />}
        {page === "service-areas"   && <ServiceAreasPage onInquiry={openInquiry} onNav={navigate} />}
      </main>

      <Footer onNav={navigate} />

      <InquiryModal
        open={inquiry.open}
        onClose={closeInquiry}
        seedService={inquiry.service}
        seedPackage={inquiry.package}
        seedVehicle={inquiry.vehicle}
      />

      {/* Floating quote pill — mobile + desktop quick access */}
      {!inquiry.open && (
        <button onClick={() => openInquiry()} aria-label="Get a quote"
          className="fixed bottom-5 right-5 z-40 lg:hidden btn-primary px-5 py-3.5 rounded-full text-[12px] uppercase tracking-[.14em] flex items-center gap-2 shadow-xl">
          <Icon.Send /> Get Quote
        </button>
      )}
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
