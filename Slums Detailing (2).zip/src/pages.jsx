/* =====================================================================
   DEDICATED SERVICE PAGES
   · AutoDetailingPage
   · CeramicPage
   · MaintenancePage
   · BioHazardPage
   =================================================================== */

/* ---------- shared ---------- */
function PageHero({ eyebrow, h1, sub, tone = "dark", children }) {
  return (
    <section className="relative pt-[120px] pb-16 lg:pb-20 overflow-hidden grain">
      <div className="halo absolute inset-0 pointer-events-none"></div>
      <div className="relative max-w-[1480px] mx-auto px-5 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10 items-end">
          <div className="lg:col-span-7">
            <div className="font-mono text-[11px] tracking-[.22em] text-blood-500 uppercase mb-5">{eyebrow}</div>
            <h1 className="font-display text-[56px] sm:text-[80px] lg:text-[112px] leading-[0.88] tracking-[-0.01em] text-bone text-balance">{h1}</h1>
            <p className="mt-6 max-w-[560px] text-white/65 text-[15px] leading-[1.7] text-pretty">{sub}</p>
          </div>
          <div className="lg:col-span-5">{children}</div>
        </div>
      </div>
    </section>
  );
}

function PackageCard({ pkg, onPick }) {
  return (
    <div className={`relative bg-ink-700 border ${pkg.badge ? "border-blood-500/35" : "border-white/8"} p-6 lg:p-7 flex flex-col`}>
      {pkg.badge && (
        <div className="absolute -top-3 left-6 font-mono text-[9.5px] tracking-[.22em] uppercase bg-blood-500 text-white px-2.5 py-1">
          {pkg.badge}
        </div>
      )}
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="font-mono text-[10px] tracking-[.22em] text-blood-500 uppercase">{pkg.duration}</div>
          <h3 className="font-display text-[32px] lg:text-[40px] text-bone leading-none mt-1.5">{pkg.name}</h3>
          <p className="text-[13.5px] text-white/60 mt-2 max-w-[400px]">{pkg.tagline}</p>
        </div>
        <div className="text-right">
          <div className="font-mono text-[9.5px] tracking-[.22em] text-white/40 uppercase">FROM</div>
          <div className="font-display text-[44px] text-blood-400 leading-none mt-1">
            {pkg.custom ? "Quote" : `$${pkg.base}`}
          </div>
        </div>
      </div>

      <p className="mt-5 text-[14px] text-white/70 leading-[1.65]">{pkg.summary}</p>

      <ul className="mt-5 grid sm:grid-cols-2 gap-x-5 gap-y-2">
        {pkg.includes.map(inc => (
          <li key={inc} className="flex items-start gap-2 text-[12.5px] text-white/70">
            <span className="text-blood-400 mt-0.5"><Icon.Check /></span>
            <span>{inc}</span>
          </li>
        ))}
      </ul>

      <div className="mt-auto pt-6 flex items-center gap-3">
        <button onClick={() => onPick(pkg)} className="btn-primary px-5 py-3 rounded-sm text-[11px] uppercase tracking-[.16em] flex items-center gap-2">
          Get Quote <Icon.Arrow />
        </button>
        {!pkg.custom && (
          <div className="font-mono text-[10.5px] tracking-[.18em] text-white/45 uppercase">
            Sedan ${pkg.pricing.sedan} · SUV ${pkg.pricing.suv} · Truck ${pkg.pricing.truck}
          </div>
        )}
      </div>
    </div>
  );
}
window.PackageCard = PackageCard;


/* ============================================================
   AUTO DETAILING PAGE
   ============================================================ */
function AutoDetailingPage({ onInquiry, onNav }) {
  const detailPkgs = PACKAGES.filter(p => p.category === "detail");
  return (
    <>
      <PageHero
        eyebrow="// SERVICE 01 — AUTO DETAILING"
        h1={<>Auto Detailing<br/><span className="text-blood-500">in Martinsburg, WV</span></>}
        sub="Six packages, from a quick 2-hour clay-and-seal exterior to our flagship 9-hour Luxury Full Detail. Mobile to your driveway, owner-finished by Dominick, every time."
      >
        <Placeholder label="exterior · hand-wash setup" aspect="4/5" code="AD-001" tone="blood" />
      </PageHero>

      <TrustBar />

      <section className="relative bg-ink-900 py-20 lg:py-24">
        <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
          <SectionHeader
            eyebrow="// PACKAGES"
            title={<>Pick the level<br/>your car <span className="text-blood-500">deserves</span>.</>}
            right="Prices shown are starting for a sedan / sports car. SUV / crossover and truck pricing scales per package — see the line under each card."
          />
          <ConditionDisclaimer className="mt-10" />
          <div className="grid lg:grid-cols-2 gap-5 mt-6">
            {detailPkgs.map(p => <PackageCard key={p.id} pkg={p} onPick={(pkg) => onInquiry({ service: "detail", package: pkg.id })} />)}
          </div>
        </div>
      </section>

      <section className="relative bg-ink-800 py-20 lg:py-24">
        <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
          <SectionHeader eyebrow="// ADD-ONS" title={<>Tack on what your <span className="text-blood-500">car needs</span>.</>} />
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3 mt-12">
            {ADDONS.map(a => (
              <div key={a.id} className="bg-ink-700 border border-white/8 p-5 flex items-start justify-between gap-4">
                <div>
                  <div className="text-[14px] text-bone">{a.name}</div>
                  <div className="text-[12px] text-white/55 mt-1">{a.blurb}</div>
                </div>
                <div className="font-display text-[28px] text-blood-400 leading-none">+${a.price}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <BuildPackageSection id="build-detail" />
    </>
  );
}
window.AutoDetailingPage = AutoDetailingPage;


/* ============================================================
   CERAMIC COATING PAGE
   ============================================================ */
function CeramicPage({ onInquiry, onNav }) {
  const ceramic = PACKAGES.filter(p => p.category === "ceramic");
  return (
    <>
      <PageHero
        eyebrow="// SERVICE 02 — CERAMIC COATING"
        h1={<>Ceramic Coating<br/><span className="text-blood-500">Martinsburg, WV</span></>}
        sub="Gyeon-certified ceramic systems with proper paint prep. 3-year and 5-year options. Hydrophobic, UV-stable, gloss for the life of the coating — warrantied."
      >
        <Placeholder label="ceramic · 5yr Syncro install" aspect="4/5" code="CER-001" tone="blood" />
      </PageHero>

      <TrustBar />

      {/* WHY CERAMIC */}
      <section className="relative bg-ink-900 py-20 lg:py-24">
        <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
          <SectionHeader
            eyebrow="// WHY CERAMIC"
            title={<>Protection that<br/>actually <span className="text-blood-500">protects</span>.</>}
            right="A proper ceramic coating bonds chemically to your clear coat. It's hydrophobic, UV-stable, chemical-resistant, and it self-cleans far better than wax or sealant ever could."
          />
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-px mt-12 bg-white/5">
            {[
              ["110°+", "Water contact angle", "Beads & rolls vs. sheets out"],
              ["98%",   "UV protection",      "Stops oxidation + fading"],
              ["2–12",  "pH chemical range",  "Survives harsh detergents"],
              ["50%",   "Less washing",       "Self-cleans in the rain"],
            ].map(([n, t, b]) => (
              <div key={t} className="bg-ink-900 p-8 lg:p-10">
                <div className="font-display text-[56px] lg:text-[68px] text-blood-500 leading-none">{n}</div>
                <div className="font-mono text-[10px] tracking-[.22em] text-white/45 uppercase mt-3">{t}</div>
                <div className="text-[13px] text-white/60 mt-1.5">{b}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PACKAGES */}
      <section className="relative bg-ink-800 py-20 lg:py-24">
        <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
          <SectionHeader
            eyebrow="// CERAMIC PACKAGES"
            title={<>Three coating <span className="text-blood-500">tiers</span>.</>}
            right="The right tier depends on paint condition and how long you plan to keep the car. We'll inspect on quote and recommend honestly — even if it's the smaller package."
          />
          <ConditionDisclaimer className="mt-10" />
          <div className="grid lg:grid-cols-1 gap-5 mt-6">
            {ceramic.map(p => <PackageCard key={p.id} pkg={p} onPick={(pkg) => onInquiry({ service: "ceramic", package: pkg.id })} />)}
          </div>
        </div>
      </section>

      {/* === PROTECTION TIME MACHINE (moved here per request) === */}
      <section className="relative bg-ink-900 py-20 lg:py-24">
        <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
          <SectionHeader
            eyebrow="// PROTECTION TIME MACHINE"
            title={<>Watch protection<br/>age over <span className="text-blood-500">5 years</span>.</>}
            right="Press play and watch how untreated paint, a wax sealant, a 3-year ceramic, and a 5-year ceramic each hold up to identical environmental wear."
          />
          <div className="mt-10">
            <ProtectionTimeMachine paintColor="#0E1116" />
          </div>
        </div>
      </section>

      <BuildPackageSection id="build-ceramic" />
    </>
  );
}
window.CeramicPage = CeramicPage;


/* ============================================================
   MAINTENANCE PROGRAM PAGE
   ============================================================ */
function MaintenancePage({ onInquiry }) {
  const [planId, setPlanId] = React.useState("biweekly");
  const [prepayId, setPrepayId] = React.useState("prepay-3");
  const plan = PLANS.find(p => p.id === planId);
  const prepay = PREPAY_OPTIONS.find(p => p.id === prepayId);
  const monthly = plan.price;
  const gross = monthly * prepay.months;
  const net = Math.round(gross * (1 - prepay.discount));
  const saved = gross - net;

  return (
    <>
      <PageHero
        eyebrow="// SERVICE 03 — MAINTENANCE PROGRAM"
        h1={<>Maintenance plans<br/>that <span className="text-blood-500">show up</span>.</>}
        sub="Weekly, bi-weekly, or monthly. Same Dominick, same standards, same driveway. Prepay 3 / 6 / 12 months and save up to 20%."
      >
        <Placeholder label="maintenance · monthly visit" aspect="4/5" code="MNT-001" />
      </PageHero>

      <TrustBar />

      {/* PLAN PICKER */}
      <section className="relative bg-ink-900 py-20 lg:py-24">
        <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
          <SectionHeader eyebrow="// PLANS" title={<>Three cadences.<br/>One <span className="text-blood-500">standard</span>.</>} />

          <div className="grid md:grid-cols-3 gap-4 mt-12">
            {PLANS.map(p => {
              const on = planId === p.id;
              return (
                <button key={p.id} onClick={() => setPlanId(p.id)}
                  className={`text-left p-7 border transition-all ${on ? "bg-blood-500/12 border-blood-500/55" : "bg-ink-700 border-white/8 hover:border-white/25"}`}>
                  <div className="font-mono text-[10px] tracking-[.22em] uppercase text-blood-500">{p.cadence}</div>
                  <h3 className="font-display text-[32px] text-bone leading-tight mt-1">{p.name}</h3>
                  <div className="mt-4 flex items-baseline gap-2">
                    <span className="font-display text-[44px] text-bone leading-none">${p.price}</span>
                    <span className="text-white/45 text-[13px]">/month</span>
                  </div>
                  <p className="mt-4 text-[13px] text-white/65 leading-[1.6]">{p.summary}</p>
                </button>
              );
            })}
          </div>

          {/* PREPAY CALCULATOR */}
          <div className="mt-12 bg-ink-700 border border-white/8">
            <div className="p-5 lg:p-7 border-b border-white/8">
              <div className="font-mono text-[10px] tracking-[.22em] text-blood-500 uppercase">// PREPAY CALCULATOR</div>
              <h3 className="font-display text-[28px] text-bone leading-tight mt-1">Save up to 20% by prepaying</h3>
            </div>
            <div className="p-5 lg:p-7 grid lg:grid-cols-12 gap-6 items-center">
              <div className="lg:col-span-7">
                <label className="field-label block mb-3">Prepay term</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {PREPAY_OPTIONS.map(o => {
                    const on = prepayId === o.id;
                    return (
                      <button key={o.id} onClick={() => setPrepayId(o.id)}
                        className={`px-3 py-3 border transition-all ${on ? "bg-blood-500/15 border-blood-500/55 text-bone" : "bg-ink-800 border-white/10 text-white/70 hover:border-white/25"}`}>
                        <div className="text-[12px]">{o.label}</div>
                        <div className="font-mono text-[10px] tracking-[.18em] text-white/45 uppercase mt-1">{o.discount > 0 ? `−${o.discount * 100}%` : "—"}</div>
                      </button>
                    );
                  })}
                </div>
              </div>
              <div className="lg:col-span-5 bg-ink-800 border border-white/8 p-5">
                <div className="flex justify-between text-[13px] text-white/70"><span>{plan.name}</span><span className="font-mono text-bone">${monthly}/mo</span></div>
                <div className="flex justify-between text-[13px] text-white/70 mt-1"><span>× {prepay.months} month{prepay.months > 1 ? "s" : ""}</span><span className="font-mono text-white/55">${gross}</span></div>
                {prepay.discount > 0 && (
                  <div className="flex justify-between text-[13px] text-blood-400 mt-1"><span>Prepay discount</span><span className="font-mono">−${saved}</span></div>
                )}
                <div className="mt-3 pt-3 border-t border-white/8 flex items-end justify-between">
                  <span className="font-mono text-[10px] tracking-[.2em] text-white/55 uppercase">Total</span>
                  <span className="font-display text-[36px] text-blood-400 leading-none">${net}</span>
                </div>
                <button onClick={() => onInquiry({ service: "plan" })}
                  className="mt-4 w-full btn-primary px-5 py-3 rounded-sm text-[11px] uppercase tracking-[.16em] flex items-center justify-center gap-2">
                  Lock In This Plan <Icon.Arrow />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <BuildPackageSection id="build-maintenance" />
    </>
  );
}
window.MaintenancePage = MaintenancePage;


/* ============================================================
   BIO-HAZARD PAGE
   ============================================================ */
function BioHazardPage({ onInquiry }) {
  const bio = PACKAGES.find(p => p.id === "bio-hazard");
  return (
    <>
      <PageHero
        eyebrow="// SERVICE 04 — BIO-HAZARD CLEANING"
        h1={<>Bio-Hazard<br/><span className="text-blood-500">Cleaning</span>.</>}
        sub="Specialized cleaning for biohazardous contamination — bodily fluids, animal waste, mold, severe organic decomposition. Pricing is custom because the work and exposure are."
      >
        <Placeholder label="biohazard · ppe + protocol" aspect="4/5" code="BIO-001" tone="blood" />
      </PageHero>

      <TrustBar />

      {/* WHY IT COSTS MORE */}
      <section className="relative bg-ink-900 py-20 lg:py-24">
        <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
          <SectionHeader
            eyebrow="// WHY IT COSTS MORE"
            title={<>This isn't a <span className="text-blood-500">detail</span>.<br/>It's a remediation.</>}
            right="A normal interior detail addresses dirt. Bio-hazard cleaning addresses risk — to you, to us, and to the next person who sits in that seat. Here's what's actually involved."
          />

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mt-12">
            {[
              { n: "01", t: "Bloodborne pathogen protocol", b: "Full PPE: Tyvek suit, nitrile double-glove, N95 + face shield. OSHA-aligned exposure control plan." },
              { n: "02", t: "Hospital-grade chemistry", b: "Enzymatic digesters, EPA-registered disinfectants. We don't 'mask' — we neutralize." },
              { n: "03", t: "Tear-down access", b: "Seats, carpets, trim — anything that wicks gets removed and treated, not surface-wiped." },
              { n: "04", t: "Ozone shock", b: "4–8 hour O₃ cycle penetrates everywhere chemicals can't, eliminating residual odor and pathogens." },
              { n: "05", t: "Regulated disposal", b: "Sharps, soiled rags, contaminated PPE — all bagged in red-bag biohazard waste, manifested for disposal." },
              { n: "06", t: "Documentation", b: "Final ATP swab + photo report. You get a written remediation record for insurance or resale." },
              { n: "07", t: "Time", b: "A normal interior is 3 hours. A bio-hazard remediation is 8–20 depending on severity." },
              { n: "08", t: "Personal exposure", b: "We accept biological risk on your behalf. That's never priced like vacuuming." },
            ].map(it => (
              <div key={it.n} className="bg-ink-700 border border-white/8 p-6">
                <div className="font-mono text-[10px] tracking-[.22em] text-blood-500 uppercase">{it.n}</div>
                <h4 className="font-display text-[22px] text-bone leading-tight mt-2">{it.t}</h4>
                <p className="text-[13px] text-white/60 leading-[1.6] mt-2">{it.b}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* WHAT WE HANDLE */}
      <section className="relative bg-ink-800 py-20 lg:py-24">
        <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
          <SectionHeader eyebrow="// SCOPE" title={<>What we <span className="text-blood-500">handle</span>.</>} />
          <div className="mt-10 grid md:grid-cols-2 lg:grid-cols-3 gap-3">
            {[
              "Blood, vomit, urine, feces",
              "Animal waste · pets, deceased wildlife",
              "Mold + mildew remediation",
              "Severe smoke + soot",
              "Sewage backup + flood-water",
              "Decomposition / unattended death cleanup",
              "Chemical / fuel spill residue",
              "Drug residue (with appropriate referral)",
              "Long-term hoarding clean-out",
            ].map(s => (
              <div key={s} className="bg-ink-700 border border-white/8 p-4 flex items-center gap-3">
                <span className="text-blood-400"><Icon.Check /></span>
                <span className="text-[13.5px] text-bone">{s}</span>
              </div>
            ))}
          </div>

          <div className="mt-10">
            <PackageCard pkg={bio} onPick={(pkg) => onInquiry({ service: "biohazard", package: pkg.id })} />
          </div>
        </div>
      </section>

      <BuildPackageSection id="build-biohazard" />
    </>
  );
}
window.BioHazardPage = BioHazardPage;
