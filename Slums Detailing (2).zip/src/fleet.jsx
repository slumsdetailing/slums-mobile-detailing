/* =====================================================================
   FLEET PAGE  ·  godetail.com/fleet-cleaning-portland inspired layout
   =====================================================================
   Sections:
   1) Hero with fleet positioning
   2) Industries we service (8 cards)
   3) Why fleets keep us on retainer (4 stat-style benefits)
   4) Service tiers (cadence + scope grid)
   5) How it works (4 step process timeline)
   6) Volume pricing / contract structure
   7) Fleet inquiry form (dedicated B2B form, not the consumer build)
   =================================================================== */

function FleetPage({ onInquiry, onNav }) {
  return (
    <>
      <FleetHero />
      <TrustBar />
      <FleetIndustries />
      <FleetBenefits />
      <FleetTiers />
      <FleetProcess />
      <FleetVolume />
      <FleetInquiry />
      <BuildPackageSection id="build-fleet" />
    </>
  );
}

/* ============================================================ */
/* 1 · HERO                                                     */
/* ============================================================ */
function FleetHero() {
  return (
    <section className="relative pt-[120px] pb-16 lg:pb-20 overflow-hidden grain">
      <div className="halo absolute inset-0 pointer-events-none"></div>
      <div className="relative max-w-[1480px] mx-auto px-5 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10 items-end">
          <div className="lg:col-span-7">
            <div className="font-mono text-[11px] tracking-[.22em] text-blood-500 uppercase mb-5">// FLEET DETAILING · B2B</div>
            <h1 className="font-display text-[56px] sm:text-[80px] lg:text-[112px] leading-[0.88] tracking-[-0.01em] text-bone text-balance">
              Your fleet, on a<br/>
              <span className="text-blood-500">contract</span>.<br/>
              No surprises.
            </h1>
            <p className="mt-6 max-w-[600px] text-white/65 text-[15px] leading-[1.7] text-pretty">
              Dealerships, rideshare partners, rental lots, delivery vans, executive cars, government and municipal fleets — we set up a standing schedule, show up on the same day each week, and your vehicles always look the way you'd want a customer to see them.
            </p>

            <div className="mt-9 flex flex-wrap items-center gap-4">
              <button onClick={() => document.getElementById("fleet-inquiry")?.scrollIntoView({ behavior: "smooth" })}
                className="btn-primary px-7 py-4 rounded-sm text-[13px] uppercase tracking-[.16em] flex items-center gap-3">
                Request Fleet Quote <Icon.Arrow />
              </button>
              <a href={BUSINESS.phoneHref} className="btn-ghost px-7 py-4 rounded-sm text-[13px] uppercase tracking-[.16em] flex items-center gap-3">
                <Icon.Phone /> {BUSINESS.phone}
              </a>
            </div>

            <div className="mt-12 grid grid-cols-3 gap-4 max-w-[580px]">
              {[
                ["8+", "Active fleet contracts"],
                ["20%", "Off retail · volume pricing"],
                ["48 hr", "Avg quote turnaround"],
              ].map(([n, l]) => (
                <div key={l} className="border-l border-white/10 pl-4">
                  <div className="font-display text-[36px] lg:text-[44px] text-bone leading-none">{n}</div>
                  <div className="font-mono text-[10px] tracking-[.18em] text-white/45 uppercase mt-2 leading-snug">{l}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-5 relative">
            <Placeholder label="fleet lineup · dealership row" aspect="4/5" code="FLT-001" tone="blood" />
            <div className="absolute -bottom-6 right-4 lg:-right-6 bg-ink-700/95 backdrop-blur border border-white/10 p-4 w-[260px]">
              <div className="font-mono text-[9px] tracking-[.22em] text-blood-500 uppercase mb-3">// CURRENT CLIENT</div>
              <div className="space-y-2 text-[11px] font-mono text-white/70">
                <div className="flex justify-between"><span className="text-white/40">CLIENT</span><span className="text-bone">Eastern Auto Group</span></div>
                <div className="flex justify-between"><span className="text-white/40">VEHICLES</span><span className="text-bone">42 lot · 6 mgmt</span></div>
                <div className="flex justify-between"><span className="text-white/40">CADENCE</span><span className="text-bone">Bi-weekly</span></div>
                <div className="flex justify-between"><span className="text-white/40">DAY</span><span className="text-bone">Mon · 6am–11am</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ============================================================ */
/* 2 · INDUSTRIES                                               */
/* ============================================================ */
function FleetIndustries() {
  const industries = [
    { code: "I/01", icon: "Car",    title: "Auto Dealerships",     body: "Lot prep, demo cars, customer delivery details, executive offices. Same-day turnarounds for high-margin units." },
    { code: "I/02", icon: "Truck",  title: "Rental & Rideshare",   body: "Turn-around cleaning between rentals, deep cleans on contract end, rideshare quarterly resets." },
    { code: "I/03", icon: "Truck",  title: "Delivery & Logistics", body: "Cargo vans, sprinters, last-mile vehicles. Exterior + cargo bay sanitation programs." },
    { code: "I/04", icon: "Suv",    title: "Corporate Fleets",     body: "Sales, executive, and pool vehicles. We're the reason your reps don't show up in a swirled-paint Tahoe." },
    { code: "I/05", icon: "Shield", title: "Government / Muni",    body: "Police cruisers, public works, transit. Bonded, insured, and prevailing-wage compliant where required." },
    { code: "I/06", icon: "Suv",    title: "Limo & Black Car",     body: "Show-condition every shift. We work around your peak hours so the cars are always ready." },
    { code: "I/07", icon: "Drop",   title: "Real Estate Showings", body: "Listing-day exterior + interior details so the car in the driveway looks as good as the house." },
    { code: "I/08", icon: "Hazard", title: "Specialty / Med",      body: "Mobile clinics, transport, hazmat-aware bio cleaning. Custom protocols on file." },
  ];
  return (
    <section className="relative bg-ink-900 py-24 lg:py-28">
      <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
        <SectionHeader
          eyebrow="// 01 — INDUSTRIES"
          title={<>Fleets we keep<br/><span className="text-blood-500">contracts</span> with.</>}
          right="If you run more than 5 vehicles and they have a customer-facing role, we have a program for you. New verticals welcome — just tell us how your day-of-service window looks."
        />
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-px mt-14 bg-white/5">
          {industries.map(it => {
            const I = Icon[it.icon] || Icon.Car;
            return (
              <div key={it.code} className="bg-ink-900 p-7 group hover:bg-ink-700 transition-colors">
                <div className="flex items-center justify-between mb-6">
                  <div className="text-blood-500 group-hover:text-blood-400 transition-colors"><I /></div>
                  <div className="font-mono text-[10px] tracking-[.22em] text-white/30">{it.code}</div>
                </div>
                <h3 className="font-display text-[26px] leading-tight text-bone">{it.title}</h3>
                <p className="mt-3 text-white/60 text-[13px] leading-[1.65]">{it.body}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ============================================================ */
/* 3 · BENEFITS                                                 */
/* ============================================================ */
function FleetBenefits() {
  const items = [
    { stat: "+22%", label: "Higher resale value", body: "Detailed lot vehicles move faster and command higher per-unit margin. We've measured it with multiple dealer clients." },
    { stat: "−40%", label: "Internal cleaning cost", body: "Pay-as-needed in-house cleaning costs more than a flat retainer once you account for staff time and product." },
    { stat: "100%", label: "Brand consistency", body: "Every vehicle, every visit, finished to the same standard. Your customers never see one car that breaks the line." },
    { stat: "0 hr", label: "Logistics on your end", body: "We arrive with water, power, supplies, schedule, and reporting. You sign once. We show up the rest of the year." },
  ];
  return (
    <section className="relative bg-ink-800 py-24 lg:py-28">
      <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
        <SectionHeader
          eyebrow="// 02 — WHY FLEETS SWITCH"
          title={<>The case for<br/><span className="text-blood-500">outsourcing it</span>.</>}
        />
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mt-14">
          {items.map(it => (
            <div key={it.label} className="bg-ink-700 border border-white/8 p-7">
              <div className="font-display text-[64px] lg:text-[72px] text-blood-500 leading-none">{it.stat}</div>
              <div className="font-mono text-[10px] tracking-[.22em] text-white/45 uppercase mt-3">{it.label}</div>
              <p className="mt-3 text-white/65 text-[13px] leading-[1.65]">{it.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============================================================ */
/* 4 · TIERS                                                    */
/* ============================================================ */
function FleetTiers() {
  const tiers = [
    {
      name: "Lot Prep",
      cadence: "Weekly · Mon–Wed",
      best: "Dealerships · rental lots",
      includes: ["Foam wash + hand finish", "Wheels + tires dressed", "Glass · interior + exterior", "Quick interior wipe", "Lot-presentation finish"],
    },
    {
      name: "Turn-Around",
      cadence: "Per-vehicle · on-call",
      best: "Rideshare · rental returns",
      includes: ["Full interior vac + wipedown", "Hot extraction on demand", "Exterior wash + tire shine", "Sanitization + scent reset", "Turn-around in 60–90 min"],
      badge: "MOST BOOKED",
    },
    {
      name: "Executive",
      cadence: "Bi-weekly · scheduled",
      best: "Corp · limo · black car",
      includes: ["Detailing-grade interior", "2-bucket hand wash", "Leather conditioning", "Glass · streak-free", "Photo-report after each visit"],
    },
    {
      name: "Show Standard",
      cadence: "Weekly · concierge",
      best: "Demo · executive · VIP",
      includes: ["Maintenance polish · DA", "Ceramic upkeep included", "Full interior detail", "Engine bay quarterly", "ATP swab pass quarterly"],
    },
  ];
  return (
    <section className="relative bg-ink-900 py-24 lg:py-28">
      <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
        <SectionHeader
          eyebrow="// 03 — SERVICE TIERS"
          title={<>Pick the cadence<br/>that fits your <span className="text-blood-500">operation</span>.</>}
          right="Every tier is a starting point. Final scope is built around your fleet size, vehicle mix, and the windows we have to work within."
        />

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-3 mt-14">
          {tiers.map((t, i) => (
            <div key={t.name} className={`relative bg-ink-700 border ${t.badge ? "border-blood-500/40" : "border-white/8"} p-6 flex flex-col`}>
              {t.badge && <div className="absolute -top-3 left-6 font-mono text-[9.5px] tracking-[.22em] uppercase bg-blood-500 text-ink-900 px-2.5 py-1">{t.badge}</div>}
              <div className="font-mono text-[10px] tracking-[.22em] text-blood-500 uppercase">TIER/0{i+1}</div>
              <h3 className="font-display text-[30px] text-bone leading-tight mt-1">{t.name}</h3>
              <div className="font-mono text-[10.5px] tracking-[.18em] text-white/55 uppercase mt-2">{t.cadence}</div>
              <div className="text-[12px] text-white/60 mt-1">Best for · <span className="text-bone">{t.best}</span></div>

              <ul className="mt-5 space-y-2 flex-1">
                {t.includes.map(inc => (
                  <li key={inc} className="flex items-start gap-2 text-[12.5px] text-white/70">
                    <span className="text-blood-400 mt-0.5"><Icon.Check /></span>
                    <span>{inc}</span>
                  </li>
                ))}
              </ul>

              <button onClick={() => document.getElementById("fleet-inquiry")?.scrollIntoView({ behavior: "smooth" })}
                className="mt-6 btn-ghost px-4 py-3 rounded-sm text-[11px] uppercase tracking-[.16em] flex items-center justify-center gap-2">
                Quote This Tier <Icon.Arrow />
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============================================================ */
/* 5 · PROCESS                                                  */
/* ============================================================ */
function FleetProcess() {
  const steps = [
    { n: "01", t: "Site visit",  b: "We come to your lot, count vehicles, take notes on access, water, runoff, electrical. 30-minute walkthrough." },
    { n: "02", t: "Written SOW", b: "You get a written scope of work + transparent pricing with volume bands. No back-and-forth, no upsells." },
    { n: "03", t: "Recurring schedule", b: "Locked-in day and arrival window. Same crew, same standards. Calendar invite sent." },
    { n: "04", t: "Photo reporting", b: "Every visit produces a photo + checklist report so your ops team can verify completion without leaving their desk." },
  ];
  return (
    <section className="relative bg-ink-800 py-24 lg:py-28">
      <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
        <SectionHeader
          eyebrow="// 04 — HOW IT WORKS"
          title={<>From inquiry to<br/>first visit <span className="text-blood-500">in 5 days</span>.</>}
        />
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-px mt-14 bg-white/5">
          {steps.map((s, i) => (
            <div key={s.n} className="bg-ink-800 p-8 lg:p-10 relative">
              <div className="font-display text-[88px] text-blood-500/20 leading-none">{s.n}</div>
              <div className="font-mono text-[10px] tracking-[.22em] text-blood-500 uppercase mt-3">STEP {s.n}</div>
              <h3 className="font-display text-[26px] text-bone mt-2 leading-tight">{s.t}</h3>
              <p className="mt-3 text-white/60 text-[13.5px] leading-[1.65]">{s.b}</p>
              {i < steps.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-3 text-blood-500/60 z-10"><Icon.Arrow /></div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============================================================ */
/* 6 · VOLUME PRICING                                           */
/* ============================================================ */
function FleetVolume() {
  const bands = [
    { range: "5 — 14",  off: "10%", note: "Standing schedule · monthly billing" },
    { range: "15 — 29", off: "15%", note: "Net-30 invoicing · dedicated point-of-contact" },
    { range: "30 — 75", off: "20%", note: "Multi-day visits · COI on file · custom SLA" },
    { range: "76+",     off: "Bespoke", note: "Quoted at SOW · onsite-day operations plan" },
  ];
  return (
    <section className="relative bg-ink-900 py-24 lg:py-28">
      <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
        <SectionHeader
          eyebrow="// 05 — VOLUME"
          title={<>The more vehicles,<br/>the better the <span className="text-blood-500">rate</span>.</>}
          right="Volume discounts apply against our standard retail. Combine with a quarterly prepay for additional 5% off — call us and we'll model your specific fleet."
        />
        <div className="mt-14 bg-ink-700 border border-white/8 overflow-hidden">
          <div className="hidden md:grid grid-cols-12 gap-4 px-6 py-4 border-b border-white/10 bg-ink-800 font-mono text-[10px] tracking-[.22em] text-white/45 uppercase">
            <div className="col-span-3">Fleet size</div>
            <div className="col-span-2">Discount</div>
            <div className="col-span-7">Terms</div>
          </div>
          {bands.map((b, i) => (
            <div key={b.range} className={`grid grid-cols-1 md:grid-cols-12 gap-2 md:gap-4 px-6 py-5 ${i < bands.length - 1 ? "border-b border-white/5" : ""}`}>
              <div className="md:col-span-3 flex items-baseline gap-3">
                <span className="font-mono text-[10px] tracking-[.2em] text-white/40 uppercase md:hidden">SIZE</span>
                <div className="font-display text-[28px] text-bone leading-none">{b.range}</div>
                <span className="text-[12px] text-white/45 ml-1">vehicles</span>
              </div>
              <div className="md:col-span-2 flex items-center gap-3">
                <span className="font-mono text-[10px] tracking-[.2em] text-white/40 uppercase md:hidden">OFF</span>
                <div className="font-display text-[26px] text-blood-400 leading-none">{b.off}</div>
              </div>
              <div className="md:col-span-7 text-[13.5px] text-white/65 leading-[1.6]">{b.note}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============================================================ */
/* 7 · FLEET INQUIRY FORM                                       */
/* ============================================================ */
function FleetInquiry() {
  const [form, setForm] = React.useState({
    company: "", contact: "", phone: "", email: "",
    size: "", mix: [], cadence: "", location: "", notes: "",
  });
  const [errors, setErrors] = React.useState({});
  const [sent, setSent] = React.useState(false);

  const toggleMix = (k) =>
    setForm(f => ({ ...f, mix: f.mix.includes(k) ? f.mix.filter(x => x !== k) : [...f.mix, k] }));

  const submit = () => {
    const e = {};
    if (!form.company.trim()) e.company = "required";
    if (!form.contact.trim()) e.contact = "required";
    if (!/^[\d\s\-\(\)\+]{7,}$/.test(form.phone)) e.phone = "valid phone required";
    if (form.email && !/^\S+@\S+\.\S+$/.test(form.email)) e.email = "valid email";
    if (!form.size.trim()) e.size = "required";
    setErrors(e);
    if (Object.keys(e).length === 0) setSent(true);
  };

  return (
    <section id="fleet-inquiry" className="relative bg-ink-800 py-24 lg:py-28 overflow-hidden">
      <div className="absolute inset-0 halo opacity-50 pointer-events-none"></div>
      <div className="relative max-w-[1100px] mx-auto px-5 lg:px-10">
        <div className="font-mono text-[11px] tracking-[.22em] text-blood-500 uppercase mb-5">// 06 — FLEET INQUIRY</div>
        <h2 className="font-display text-[44px] sm:text-[64px] lg:text-[88px] leading-[0.9] tracking-[-0.01em] text-bone text-balance">
          Tell us about your<br/><span className="text-blood-500">fleet</span>. We'll do the rest.
        </h2>

        {sent ? (
          <div className="mt-10 bg-ink-900 border border-white/10 p-10 text-center">
            <div className="w-16 h-16 bg-blood-500/15 border border-blood-500/40 rounded-full mx-auto flex items-center justify-center text-blood-400">
              <Icon.Check />
            </div>
            <h3 className="font-display text-[40px] text-bone mt-5">Request received.</h3>
            <p className="text-white/65 text-[14px] mt-3 max-w-[440px] mx-auto leading-[1.7]">
              We'll text <span className="font-mono text-blood-400">{form.phone}</span> within one business day to set up a site visit at <span className="text-bone">{form.company}</span>.
            </p>
          </div>
        ) : (
          <div className="mt-10 bg-ink-900 border border-white/10 p-6 lg:p-9">
            <div className="grid sm:grid-cols-12 gap-4">
              <div className="sm:col-span-7">
                <FLbl k="Company / Organization" err={errors.company} />
                <input className={`field ${errors.company ? "border-rose-500/55" : ""}`}
                  value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })}
                  placeholder="Eastern Auto Group" />
              </div>
              <div className="sm:col-span-5">
                <FLbl k="Industry · optional" />
                <select className="field" value={form.industry || ""} onChange={(e) => setForm({ ...form, industry: e.target.value })}>
                  <option value="">Select…</option>
                  <option>Dealership</option>
                  <option>Rental / Rideshare</option>
                  <option>Delivery / Logistics</option>
                  <option>Corporate Fleet</option>
                  <option>Government / Municipal</option>
                  <option>Limo / Black Car</option>
                  <option>Other</option>
                </select>
              </div>

              <div className="sm:col-span-6">
                <FLbl k="Your Name" err={errors.contact} />
                <input className={`field ${errors.contact ? "border-rose-500/55" : ""}`}
                  value={form.contact} onChange={(e) => setForm({ ...form, contact: e.target.value })}
                  placeholder="Dominick Smith" />
              </div>
              <div className="sm:col-span-3">
                <FLbl k="Phone" err={errors.phone} />
                <input className={`field ${errors.phone ? "border-rose-500/55" : ""}`}
                  value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  placeholder="(304) 555-0199" />
              </div>
              <div className="sm:col-span-3">
                <FLbl k="Email" err={errors.email} />
                <input className={`field ${errors.email ? "border-rose-500/55" : ""}`}
                  value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="ops@company.com" />
              </div>

              <div className="sm:col-span-4">
                <FLbl k="Fleet size" err={errors.size} />
                <select className={`field ${errors.size ? "border-rose-500/55" : ""}`}
                  value={form.size} onChange={(e) => setForm({ ...form, size: e.target.value })}>
                  <option value="">Select…</option>
                  <option>5 — 14 vehicles</option>
                  <option>15 — 29 vehicles</option>
                  <option>30 — 75 vehicles</option>
                  <option>76+ vehicles</option>
                </select>
              </div>
              <div className="sm:col-span-4">
                <FLbl k="Service cadence · interest" />
                <select className="field" value={form.cadence} onChange={(e) => setForm({ ...form, cadence: e.target.value })}>
                  <option value="">Select…</option>
                  <option>Weekly</option>
                  <option>Bi-weekly</option>
                  <option>Monthly</option>
                  <option>Per-vehicle / on-call</option>
                  <option>Not sure yet</option>
                </select>
              </div>
              <div className="sm:col-span-4">
                <FLbl k="Location · city" />
                <input className="field"
                  value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })}
                  placeholder="Martinsburg, WV" />
              </div>

              <div className="sm:col-span-12">
                <FLbl k="Vehicle mix · pick all that apply" />
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {["Sedans / coupes","SUVs / crossovers","Pickup trucks","Cargo vans","Sprinters / box trucks","Heavy duty","Motorcycles","Specialty"].map(m => {
                    const on = form.mix.includes(m);
                    return (
                      <button key={m} type="button" onClick={() => toggleMix(m)}
                        className={`text-left p-3 border transition-all ${on ? "bg-blood-500/12 border-blood-500/55" : "bg-ink-800 border-white/10 hover:border-white/25"}`}>
                        <div className="flex items-center justify-between">
                          <span className="text-[12.5px] text-bone">{m}</span>
                          <span className={`w-4 h-4 border flex items-center justify-center ${on ? "bg-blood-500 border-blood-500" : "border-white/25"}`}>
                            {on && <span className="text-ink-900 scale-75"><Icon.Check /></span>}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="sm:col-span-12">
                <FLbl k="Anything else? · access, hours, requirements" />
                <textarea className="field min-h-[90px] resize-none"
                  value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  placeholder="Lot is gated · access 6am–11am · indoor bay available · COI required, etc." />
              </div>
            </div>

            <div className="mt-6 flex items-center justify-between gap-3 flex-wrap">
              <div className="font-mono text-[10px] tracking-[.2em] text-white/40 uppercase">
                Net-30 invoicing · COI provided · we mobilize within 5 business days of signed SOW
              </div>
              <button onClick={submit} className="btn-primary px-6 py-4 rounded-sm text-[12px] uppercase tracking-[.16em] flex items-center gap-2">
                Send Fleet Request <Icon.Send />
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

function FLbl({ k, err }) {
  return (
    <div className="flex items-center justify-between mb-2">
      <label className="field-label">{k}</label>
      {err && <span className="font-mono text-[10px] tracking-[.18em] uppercase text-rose-500">! {err}</span>}
    </div>
  );
}

window.FleetPage = FleetPage;
