// Editable image placeholder — wraps the <image-slot> web component so the
// user can drag-and-drop (or click to browse) a real photo in. The dropped
// image persists across reloads via the image-slot sidecar.
//
// `code` is used as the stable persistence id (sanitized), so every distinct
// placeholder keeps its own image. `label` becomes the empty-state caption.
function Placeholder({ label = "image", aspect = "4/3", tone = "dark", className = "", code = "IMG-001" }) {
  const id = "slot-" + String(code).replace(/[^a-z0-9]/gi, "-").toLowerCase();
  return (
    <div className={`relative w-full overflow-hidden ${className}`} style={{ aspectRatio: aspect }}>
      <image-slot
        id={id}
        class="absolute inset-0 block"
        style={{ width: "100%", height: "100%" }}
        shape="rect"
        fit="cover"
        placeholder={`▢  ${label}`}
      ></image-slot>
    </div>
  );
}
window.Placeholder = Placeholder;
