/* =====================================================================
   HOME PAGE · hero, services, social proof, gallery, FAQ, testimonials
   =================================================================== */

function Home({ onNav, onInquiry }) {
  return (
    <>
      <HomeHero onNav={onNav} onInquiry={onInquiry} />
      <TrustBar />
      <Marquee />
      <HomeServices onNav={onNav} />
      <HomeProof />
      <HomeWhy />
      <HomeGallery />
      <HomeTestimonials />
      <HomeFAQ />
      <BuildPackageSection id="build-home" />
    </>
  );
}

/* ---------- HERO --------------------------------------------------- */
function HomeHero({ onNav, onInquiry }) {
  return (
    <section className="relative overflow-hidden grain pt-[72px]">
      <div className="halo absolute inset-0 pointer-events-none"></div>
      <div className="absolute inset-0 opacity-[0.05] pointer-events-none"
           style={{
             backgroundImage: "linear-gradient(rgba(255,255,255,.4) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.4) 1px, transparent 1px)",
             backgroundSize: "80px 80px"
           }}></div>

      <div className="relative max-w-[1480px] mx-auto px-5 lg:px-10 pt-14 lg:pt-24 pb-16 lg:pb-24">
        {/* meta strip */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-10 font-mono text-[10.5px] tracking-[.22em] text-white/45 uppercase">
          <div className="flex items-center gap-3">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-blood-500 animate-pulse"></span>
            <span>Mobile · Now Booking Wk 23</span>
          </div>
          <div className="hidden md:flex items-center gap-6">
            <span>Est · 2021</span>
            <span>Martinsburg · WV</span>
            <span>Reg# WV-DTL-0418</span>
          </div>
        </div>

        <div className="grid lg:grid-cols-12 gap-10 lg:gap-12 items-end">
          <div className="lg:col-span-7">
            <div className="chip mb-6">
              <Icon.Star /> #1 Mobile Detail · Eastern Panhandle WV
            </div>

            <h1 className="font-display text-[60px] sm:text-[92px] lg:text-[128px] leading-[0.86] tracking-[-0.01em] text-bone text-balance">
              We bring the<br/>
              <span className="text-blood-500">showroom</span><br/>
              to your driveway<span className="text-blood-500">.</span>
            </h1>

            <p className="mt-8 max-w-[540px] text-white/65 text-[15px] leading-[1.7] text-pretty">
              Slums Detailing is a Martinsburg-based mobile auto detailing studio. We bring our own water, power, and a full kit of pro chemistry — ceramic coatings, paint correction, maintenance plans, and bio-hazard cleaning — anywhere within 90 minutes of Martinsburg, WV.
            </p>

            <div className="mt-9 flex flex-wrap items-center gap-4">
              <button onClick={() => document.getElementById("build-home")?.scrollIntoView({ behavior: "smooth" })} className="btn-primary px-7 py-4 rounded-sm text-[13px] uppercase tracking-[.16em] flex items-center gap-3">
                Build A Package <Icon.Arrow />
              </button>
              <button onClick={onInquiry} className="btn-ghost px-7 py-4 rounded-sm text-[13px] uppercase tracking-[.16em] flex items-center gap-3">
                Get a Quote
              </button>
            </div>

            {/* stat strip */}
            <div className="mt-14 grid grid-cols-3 gap-4 max-w-[580px]">
              {[
                ["620+", "Vehicles detailed"],
                ["4.98", "Avg · 214 verified reviews"],
                ["100%", "Mobile · we come to you"],
              ].map(([n, l]) => (
                <div key={l} className="border-l border-white/10 pl-4">
                  <div className="font-display text-[36px] lg:text-[44px] text-bone leading-none">{n}</div>
                  <div className="font-mono text-[10px] tracking-[.18em] text-white/45 uppercase mt-2 leading-snug">{l}</div>
                </div>
              ))}
            </div>
          </div>

          {/* visual */}
          <div className="lg:col-span-5 relative">
            <div className="relative">
              <Placeholder label="hero · black coupe at golden hour" aspect="4/5" code="HERO-001" tone="blood" />

              {/* sticker */}
              <div className="absolute -top-5 -left-5 lg:-left-8 w-[126px] h-[126px] rounded-full bg-blood-500 text-white flex items-center justify-center text-center font-display tracking-[.06em] rotate-[-8deg] shadow-[0_18px_45px_-10px_rgba(230,57,57,.5)]">
                <div>
                  <div className="font-mono text-[8px] tracking-[.25em] mb-1">FROM</div>
                  <div className="font-display text-[34px] leading-none">$150</div>
                  <div className="font-mono text-[8px] tracking-[.18em] mt-1">EXTERIOR · MOBILE</div>
                </div>
              </div>

              {/* spec card */}
              <div className="absolute -bottom-6 right-4 lg:-right-6 bg-ink-700/95 backdrop-blur border border-white/10 p-4 w-[240px]">
                <div className="font-mono text-[9px] tracking-[.22em] text-blood-500 uppercase mb-3">// SESSION 0417</div>
                <div className="space-y-2 text-[11px] font-mono text-white/70">
                  <Row k="VEHICLE" v="2023 M3 Comp" />
                  <Row k="PACKAGE" v="Luxury Full + Ceramic" />
                  <Row k="DURATION" v="8h 20m" />
                  <Row k="LOCATION" v="Martinsburg" />
                </div>
                <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between">
                  <span className="font-mono text-[9px] tracking-[.22em] text-white/40">STATUS</span>
                  <span className="font-mono text-[10px] text-blood-400 flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-blood-500"></span> COMPLETE
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Row({ k, v }) {
  return (
    <div className="flex justify-between gap-3">
      <span className="text-white/40">{k}</span>
      <span className="text-bone">{v}</span>
    </div>
  );
}

/* ---------- SERVICES (4 main) ------------------------------------- */
function HomeServices({ onNav }) {
  return (
    <section className="relative bg-ink-900 py-24 lg:py-32">
      <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
        <SectionHeader
          eyebrow="// 01 — Featured Services"
          title={<>Four ways we make your<br/>car look <span className="text-blood-500">expensive</span>.</>}
          right="Owner-finished work, mobile to your home, office, or shop. Within 90 minutes of Martinsburg, WV — Berkeley, Jefferson, Frederick MD, Frederick VA counties and everything in between."
        />

        <div className="grid lg:grid-cols-12 gap-4 mt-14">
          {SERVICES.map((s, i) => {
            const I = Icon[s.icon] || Icon.Drop;
            const span = i === 0 ? "lg:col-span-7" : "lg:col-span-5";
            const isBio = s.id === "biohazard";
            return (
              <button key={s.id} onClick={() => onNav(s.slug)}
                className={`relative text-left group bg-ink-700 border ${isBio ? "border-blood-500/30" : "border-white/5"} hover:border-blood-500/50 transition-all duration-300 overflow-hidden ${span} min-h-[280px]`}>
                <div className="absolute top-4 left-5 font-mono text-[10px] tracking-[.22em] text-white/35">S/0{i + 1}</div>
                {isBio && (
                  <div className="absolute top-4 right-4 font-mono text-[9px] tracking-[.2em] text-blood-400 border border-blood-500/40 px-2 py-1 bg-blood-500/5">
                    CUSTOM QUOTE
                  </div>
                )}
                <div className="p-7 pt-14 h-full flex flex-col">
                  <div className="flex items-start gap-5">
                    <div className="w-12 h-12 rounded-sm bg-blood-500/8 border border-blood-500/25 flex items-center justify-center text-blood-400 group-hover:bg-blood-500 group-hover:text-white transition-colors">
                      <I />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-display text-[32px] lg:text-[44px] text-bone leading-none">{s.name}</h3>
                    </div>
                  </div>
                  <p className="mt-5 text-white/65 text-[14px] leading-[1.65] max-w-[440px]">{s.blurb}</p>
                  <div className="mt-auto pt-6">
                    <span className="inline-flex items-center gap-2 text-[12px] uppercase tracking-[.16em] text-bone group-hover:text-blood-400 transition-colors border-b border-white/15 group-hover:border-blood-500 pb-1.5">
                      View {s.name} <Icon.Arrow />
                    </span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ---------- PROOF ------------------------------------------------- */
function HomeProof() {
  const [count, setCount] = React.useState(0);
  const ref = React.useRef(null);
  React.useEffect(() => {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          let start = 0; const target = 214;
          const step = () => { start += 7; if (start >= target) { setCount(target); return; } setCount(start); requestAnimationFrame(step); };
          requestAnimationFrame(step);
          obs.disconnect();
        }
      });
    }, { threshold: 0.3 });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  const sources = [["Google", "4.9", "162"], ["Facebook", "5.0", "31"], ["Yelp", "4.8", "21"]];

  return (
    <section ref={ref} className="relative bg-ink-800 py-24 lg:py-28 overflow-hidden">
      <div className="relative max-w-[1480px] mx-auto px-5 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-7">
            <div className="font-mono text-[11px] tracking-[.22em] text-blood-500 uppercase mb-5">// 02 — Social Proof</div>
            <h2 className="font-display text-[52px] sm:text-[76px] lg:text-[100px] leading-[0.88] text-bone tracking-[-0.01em] text-balance">
              #1 Most-rated<br/>
              mobile detailer in<br/>
              <span className="text-blood-500">Martinsburg, WV</span>
            </h2>
            <div className="mt-7 flex items-center gap-6">
              <div className="flex items-center gap-1.5 text-blood-500">
                {[0,1,2,3,4].map(i => <Icon.Star key={i} />)}
              </div>
              <div className="font-mono text-[12px] tracking-[.18em] text-white/60">
                4.98 / 5 · <span className="text-bone">{count}</span> verified reviews
              </div>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="bg-ink-900 border border-white/8 p-7">
              <div className="font-mono text-[10px] tracking-[.22em] text-white/40 uppercase mb-6 flex items-center justify-between">
                <span>// review aggregation</span>
                <span className="text-blood-400">LIVE</span>
              </div>
              <div className="space-y-5">
                {sources.map(([name, rating, n]) => (
                  <div key={name} className="flex items-center justify-between gap-4 pb-5 border-b border-white/5 last:border-b-0 last:pb-0">
                    <div>
                      <div className="font-display text-[22px] text-bone tracking-wide">{name}</div>
                      <div className="font-mono text-[10px] tracking-[.18em] text-white/40 uppercase mt-1">{n} reviews</div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-blood-500 flex"><Icon.Star /></div>
                      <span className="font-display text-[34px] text-bone leading-none">{rating}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- WHY US ------------------------------------------------ */
function HomeWhy() {
  const items = [
    { icon: "Truck",  code: "B/01", title: "100% Mobile", body: "We arrive with our own water tank, generator, and full kit. Driveway, office, garage — wherever you are." },
    { icon: "Spark",  code: "B/02", title: "Premium Products", body: "Gyeon, Koch-Chemie, Superior Products. No grocery-store soap, no shortcuts on chemistry." },
    { icon: "Shield", code: "B/03", title: "Insured & Bonded", body: "$1M general liability + garage-keeper's policy. Your vehicle is covered while we work." },
    { icon: "Clock",  code: "B/04", title: "On-Time, Every Time", body: "Tracking sent 30 minutes before arrival. If we're late, your detail is 10% off — automatically." },
    { icon: "Wrench", code: "B/05", title: "Owner-Operated", body: "Every job, every car, finished by Dominick. No subcontractors. No rotating crews." },
    { icon: "Star",   code: "B/06", title: "Satisfaction Guarantee", body: "Spot we missed? We come back within 7 days at no charge. Period." },
  ];
  return (
    <section className="relative bg-ink-900 py-24 lg:py-32">
      <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
        <SectionHeader
          eyebrow="// 03 — Why Slums"
          title={<>Six reasons your<br/>neighbor already <span className="text-blood-500">switched</span>.</>}
          right="We're not the cheapest. We're the one you tell your buddies about. The standard is set by what Dominick will let leave the driveway."
        />
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-px mt-14 bg-white/5">
          {items.map(it => {
            const I = Icon[it.icon] || Icon.Star;
            return (
              <div key={it.code} className="bg-ink-900 p-8 lg:p-10 group hover:bg-ink-700 transition-colors">
                <div className="flex items-center justify-between mb-7">
                  <div className="text-blood-500 group-hover:text-blood-400 transition-colors"><I /></div>
                  <div className="font-mono text-[10px] tracking-[.22em] text-white/30">{it.code}</div>
                </div>
                <h3 className="font-display text-[28px] lg:text-[36px] leading-[0.95] text-bone">{it.title}</h3>
                <p className="mt-4 text-white/60 text-[13.5px] leading-[1.65]">{it.body}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ---------- GALLERY (mini) ---------------------------------------- */
function HomeGallery() {
  const items = [
    { label: "2023 RS6 · ceramic + correction", code: "G/01", tone: "blood" },
    { label: "2022 GR86 · 5-yr Syncro", code: "G/02" },
    { label: "2019 4Runner · interior reset", code: "G/03" },
    { label: "2024 M3 · luxury full", code: "G/04", tone: "blood" },
    { label: "2018 F-150 · exterior", code: "G/05" },
    { label: "2020 Tahoe · deep clean", code: "G/06" },
  ];
  return (
    <section className="relative bg-ink-800 py-24 lg:py-28">
      <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
        <SectionHeader
          eyebrow="// 04 — Recent Work"
          title={<>Receipts from the<br/><span className="text-blood-500">driveway</span>.</>}
        />
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3 mt-12">
          {items.map((it, i) => (
            <figure key={it.code} className="relative overflow-hidden border border-white/5 group">
              <Placeholder label={it.label} aspect={i % 4 === 0 ? "4/5" : "4/3"} code={it.code} tone={it.tone} />
              <figcaption className="absolute bottom-0 left-0 right-0 p-5 bg-gradient-to-t from-ink-900 via-ink-900/70 to-transparent pointer-events-none">
                <div className="font-mono text-[9px] tracking-[.24em] text-blood-400 uppercase mb-1.5">{it.code}</div>
                <div className="font-display text-[22px] leading-tight text-bone tracking-wide">{it.label}</div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- TESTIMONIALS ------------------------------------------ */
const HOME_REVIEWS = [
  { quote: "Dominick showed up on time, set up in my driveway, and made my Tahoe look better than the day I drove it off the lot. Insane attention to detail.", name: "Marcus W.", car: "2017 Tahoe · Full Detail", rating: 5, loc: "Martinsburg, WV" },
  { quote: "Three kids and a Golden Retriever — my Pilot was a war zone. Slums brought it back from the dead. Carpets look brand new.", name: "Sarah K.", car: "2021 Pilot · Interior", rating: 5, loc: "Hedgesville, WV" },
  { quote: "Did the 5-yr ceramic on my GR86. Two months in, water beads like a marble countertop. Only place I'll touch my car.", name: "Tyrell J.", car: "2023 GR86 · Ceramic", rating: 5, loc: "Inwood, WV" },
];
function HomeTestimonials() {
  const [idx, setIdx] = React.useState(0);
  React.useEffect(() => {
    const t = setInterval(() => setIdx(i => (i + 1) % HOME_REVIEWS.length), 7000);
    return () => clearInterval(t);
  }, []);
  const active = HOME_REVIEWS[idx];
  return (
    <section className="relative bg-ink-900 py-24 lg:py-32 overflow-hidden">
      <div className="absolute top-10 right-10 font-display text-[420px] leading-none text-white/[0.025] select-none">”</div>
      <div className="relative max-w-[1480px] mx-auto px-5 lg:px-10">
        <SectionHeader eyebrow="// 05 — Field Reports" title={<>What folks are <span className="text-blood-500">saying</span>.</>} />
        <div className="mt-12 grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-7 bg-ink-700 border border-white/8 p-8 lg:p-12">
            <div className="flex items-center justify-between mb-7">
              <div className="flex gap-1 text-blood-500">
                {Array.from({ length: active.rating }).map((_, i) => <Icon.Star key={i} />)}
              </div>
              <div className="font-mono text-[10px] tracking-[.22em] text-white/35 uppercase">
                {String(idx + 1).padStart(2,"0")} / {String(HOME_REVIEWS.length).padStart(2,"0")}
              </div>
            </div>
            <blockquote className="font-display text-[28px] sm:text-[36px] lg:text-[44px] leading-[1.1] text-bone tracking-tight text-pretty">
              "{active.quote}"
            </blockquote>
            <div className="mt-8 pt-6 border-t border-white/8 flex items-center justify-between gap-4 flex-wrap">
              <div className="flex items-center gap-4">
                <div className="w-11 h-11 bg-blood-500/15 border border-blood-500/30 flex items-center justify-center font-display text-blood-400 text-xl">
                  {active.name[0]}
                </div>
                <div>
                  <div className="font-display text-[20px] text-bone leading-tight">{active.name}</div>
                  <div className="font-mono text-[10px] tracking-[.18em] text-white/45 uppercase mt-0.5">{active.car}</div>
                </div>
              </div>
              <div className="font-mono text-[10px] tracking-[.18em] text-white/45 uppercase flex items-center gap-2">
                <Icon.Pin /> {active.loc}
              </div>
            </div>
            <div className="mt-7 flex gap-2">
              {HOME_REVIEWS.map((_, i) => (
                <button key={i} onClick={() => setIdx(i)} aria-label={`Review ${i + 1}`}
                  className={`h-0.5 transition-all ${i === idx ? "bg-blood-500 w-12" : "bg-white/15 w-6 hover:bg-white/30"}`}></button>
              ))}
            </div>
          </div>
          <div className="lg:col-span-5 flex flex-col gap-4">
            {HOME_REVIEWS.filter((_, i) => i !== idx).map((t, i) => (
              <button key={i} onClick={() => setIdx(HOME_REVIEWS.indexOf(t))}
                className="text-left bg-ink-800 border border-white/5 p-6 hover:border-blood-500/30 hover:bg-ink-700 transition-all">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex gap-0.5 text-blood-500 text-[10px]">
                    {Array.from({ length: t.rating }).map((_, j) => <Icon.Star key={j} />)}
                  </div>
                  <div className="font-mono text-[9px] tracking-[.22em] text-white/35 uppercase">{t.loc}</div>
                </div>
                <p className="text-white/75 text-[13px] leading-[1.6]">"{t.quote.slice(0, 110)}…"</p>
                <div className="mt-4 font-mono text-[10px] tracking-[.18em] text-white/50 uppercase">— {t.name}</div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- FAQ --------------------------------------------------- */
const HOME_FAQS = [
  { q: "Do you really come to my house?", a: "Yes — we're 100% mobile within 90 minutes of Martinsburg, WV. That covers Berkeley, Jefferson, Morgan, and Frederick counties in WV/MD, plus Winchester VA and surrounding areas. We bring our own water tank (60 gal) and inverter generator." },
  { q: "How long does each service take?", a: "Express details run 2–3 hours. Full details 5–7 hours. Ceramic coatings are 1–2 day appointments depending on correction level. We give an exact window when you book." },
  { q: "Why is bio-hazard cleaning custom-quoted?", a: "Biohazard cleaning involves regulated waste handling, specialized PPE, and disposal compliance for things like bodily fluids, animal waste, or mold. Pricing varies wildly by contamination level — we quote on inspection." },
  { q: "What forms of payment do you accept?", a: "Cash, Venmo, Zelle, Apple Pay, and all major credit cards via tap-to-pay. A small deposit holds your slot; the balance is paid after we finish in your driveway." },
];

function HomeFAQ() {
  const [open, setOpen] = React.useState(0);
  return (
    <section className="relative bg-ink-800 py-24 lg:py-28">
      <div className="max-w-[1480px] mx-auto px-5 lg:px-10">
        <SectionHeader
          eyebrow="// 06 — Common Questions"
          title={<>Things people ask<br/>before they <span className="text-blood-500">book</span>.</>}
          right="Still on the fence? Text Dominick directly. He answers his own phone."
        />
        <div className="mt-10 max-w-[920px] mx-auto">
          {HOME_FAQS.map((f, i) => {
            const isOpen = open === i;
            return (
              <div key={i} className="border-b border-white/8">
                <button onClick={() => setOpen(isOpen ? -1 : i)} className="w-full flex items-center justify-between gap-6 py-6 text-left group">
                  <div className="flex items-start gap-5 flex-1">
                    <span className="font-mono text-[11px] tracking-[.22em] text-blood-500 pt-1.5">Q/{String(i+1).padStart(2,"0")}</span>
                    <span className="font-display text-[22px] lg:text-[30px] text-bone leading-tight group-hover:text-blood-400 transition-colors text-pretty">{f.q}</span>
                  </div>
                  <span className={`w-9 h-9 rounded-full border flex items-center justify-center transition-all flex-shrink-0
                    ${isOpen ? "bg-blood-500 border-blood-500 text-white rotate-180" : "border-white/15 text-bone group-hover:border-blood-500 group-hover:text-blood-400"}`}>
                    {isOpen ? <Icon.Minus /> : <Icon.Plus />}
                  </span>
                </button>
                <div className={`grid transition-all duration-500 ease-out ${isOpen ? "grid-rows-[1fr] opacity-100 pb-7" : "grid-rows-[0fr] opacity-0"}`}>
                  <div className="overflow-hidden">
                    <p className="pl-[80px] pr-12 text-white/65 text-[14.5px] leading-[1.75] max-w-[700px] text-pretty">{f.a}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

window.Home = Home;
