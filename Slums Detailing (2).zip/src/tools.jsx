/* =====================================================================
   PREMIUM TOOLS
   1) PaintCorrectionSlider — before/after with severity-specific image
                              uploads (light · moderate · heavy)
   2) CeramicVisualizer     — canvas water-bead simulation
   3) ProtectionTimeMachine — animated 5-year decay timeline
   =================================================================== */

/* ============================================================
   1 · PAINT CORRECTION SLIDER
   ============================================================
   For each severity (light / moderate / heavy), the user can upload
   a BEFORE photo and an AFTER photo. Uploaded files are read as
   DataURLs and stored in localStorage so they persist across reloads.
   If no images are uploaded yet, we render a generated swirl preview.
*/

const PC_STORAGE_KEY = "slums.paintCorrection.images.v1";

function loadPCImages() {
  try {
    const raw = localStorage.getItem(PC_STORAGE_KEY);
    if (!raw) return {};
    return JSON.parse(raw) || {};
  } catch (e) { return {}; }
}
function savePCImages(obj) {
  try { localStorage.setItem(PC_STORAGE_KEY, JSON.stringify(obj)); } catch (e) {}
}

function PaintCorrectionSlider({ paintColor = "#0E1116" }) {
  const [pos, setPos] = React.useState(50);
  const [severity, setSeverity] = React.useState("moderate"); // light | moderate | heavy
  const [images, setImages] = React.useState(() => loadPCImages());
  const ref = React.useRef(null);

  // ----- drag handle -----
  const onMove = (e) => {
    if (!ref.current) return;
    const r = ref.current.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const pct = Math.max(3, Math.min(97, ((clientX - r.left) / r.width) * 100));
    setPos(pct);
  };

  // ----- file uploads -----
  const onUpload = (sev, side) => (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = () => {
      const next = {
        ...images,
        [sev]: { ...(images[sev] || {}), [side]: reader.result },
      };
      setImages(next);
      savePCImages(next);
    };
    reader.readAsDataURL(file);
  };

  const clearImage = (sev, side) => {
    const sevObj = { ...(images[sev] || {}) };
    delete sevObj[side];
    const next = { ...images, [sev]: sevObj };
    setImages(next);
    savePCImages(next);
  };

  const current = images[severity] || {};
  const hasBefore = !!current.before;
  const hasAfter  = !!current.after;

  // ----- generated fallback strength -----
  const cLum = colorLuminance(paintColor);
  const swirlOpacity = 0.12 + (1 - cLum) * 0.55;
  const sevMul = severity === "light" ? 0.55 : severity === "moderate" ? 1 : 1.6;

  const severities = [
    { id: "light",    label: "Light",    note: "60% removal · 1-step polish" },
    { id: "moderate", label: "Moderate", note: "75% removal · 1-step polish" },
    { id: "heavy",    label: "Heavy",    note: "90%+ removal · 2-step correction" },
  ];

  return (
    <div className="bg-ink-700 border border-white/8">
      {/* header */}
      <div className="flex items-center justify-between p-5 border-b border-white/8">
        <div>
          <div className="font-mono text-[10px] tracking-[.22em] text-blood-500 uppercase">// TOOL 01</div>
          <h3 className="font-display text-[26px] text-bone leading-tight mt-1">Paint Correction · Before / After</h3>
        </div>
        <div className="hidden sm:block font-mono text-[10px] tracking-[.2em] text-white/40 uppercase">drag handle →</div>
      </div>

      {/* canvas */}
      <div className="p-5">
        <div
          ref={ref}
          className="relative h-[280px] sm:h-[360px] overflow-hidden select-none cursor-ew-resize bg-ink-900"
          style={{ background: paintColor }}
          onMouseDown={(e) => { onMove(e); const move = (ev) => onMove(ev); const up = () => { window.removeEventListener("mousemove", move); window.removeEventListener("mouseup", up); }; window.addEventListener("mousemove", move); window.addEventListener("mouseup", up); }}
          onTouchMove={onMove}
        >
          {/* === AFTER (full image layer) === */}
          {hasAfter ? (
            <img src={current.after} alt="After paint correction"
                 className="absolute inset-0 w-full h-full object-cover" draggable="false" />
          ) : (
            // generated clean paint preview
            <>
              <div className="absolute inset-0" style={{
                background: `radial-gradient(120% 80% at 30% 30%, rgba(255,255,255,.18), transparent 55%), ${paintColor}`,
              }}></div>
              <div className="absolute inset-x-0 top-0 h-1/2" style={{
                background: "linear-gradient(180deg, rgba(255,255,255,.10), transparent)",
              }}></div>
              <div className="absolute left-[10%] right-[10%] top-[18%] h-[3px] bg-white/30 blur-[3px]"></div>
              <div className="absolute bottom-3 right-3 font-mono text-[10px] tracking-[.2em] text-white/45 uppercase bg-ink-900/70 backdrop-blur px-2 py-1 border border-white/10">
                preview · upload your AFTER photo
              </div>
            </>
          )}

          {/* === BEFORE (clipped layer) === */}
          <div className="absolute inset-0 overflow-hidden" style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}>
            {hasBefore ? (
              <img src={current.before} alt="Before paint correction"
                   className="absolute inset-0 w-full h-full object-cover" draggable="false" />
            ) : (
              <>
                <div className="absolute inset-0" style={{ background: paintColor }}></div>
                <SwirlPattern opacity={swirlOpacity * sevMul} />
                <div className="absolute inset-0" style={{ background: `radial-gradient(120% 80% at 30% 30%, rgba(255,255,255,${0.06 * sevMul}), transparent 60%)` }}></div>
                {severity !== "light" && (
                  <div className="absolute inset-0" style={{
                    backgroundImage: "radial-gradient(4px 4px at 30% 60%, rgba(255,255,255,.4), transparent 50%), radial-gradient(3px 3px at 60% 40%, rgba(255,255,255,.35), transparent 50%), radial-gradient(5px 5px at 75% 70%, rgba(255,255,255,.3), transparent 50%)",
                    backgroundSize: "180px 180px, 130px 130px, 220px 220px",
                  }}></div>
                )}
                <div className="absolute bottom-3 left-3 font-mono text-[10px] tracking-[.2em] text-white/45 uppercase bg-ink-900/70 backdrop-blur px-2 py-1 border border-white/10">
                  preview · upload your BEFORE photo
                </div>
              </>
            )}
          </div>

          {/* labels */}
          <div className="absolute top-3 left-3 font-mono text-[10px] tracking-[.2em] uppercase bg-ink-900/80 backdrop-blur px-2.5 py-1 border border-white/10 text-white/80 z-[5]">BEFORE</div>
          <div className="absolute top-3 right-3 font-mono text-[10px] tracking-[.2em] uppercase bg-blood-500 text-ink-900 px-2.5 py-1 z-[5]">AFTER</div>

          {/* handle */}
          <div className="ba-handle" style={{ left: `${pos}%` }}></div>
        </div>

        {/* === severity controls === */}
        <div className="mt-4 grid sm:grid-cols-3 gap-2">
          {severities.map(s => {
            const on = severity === s.id;
            const sevImgs = images[s.id] || {};
            const ready = !!(sevImgs.before && sevImgs.after);
            return (
              <button key={s.id} onClick={() => setSeverity(s.id)}
                className={`text-left px-4 py-3 border transition-all
                  ${on ? "bg-blood-500/12 border-blood-500/50" : "bg-ink-800 border-white/8 hover:border-white/20"}`}>
                <div className="flex items-center justify-between">
                  <div className="font-mono text-[10px] tracking-[.2em] uppercase text-white/40">SEVERITY</div>
                  {ready && <span className="font-mono text-[9px] tracking-[.2em] uppercase text-blood-400">●  PHOTOS</span>}
                </div>
                <div className={`font-display text-[22px] leading-none mt-1 ${on ? "text-blood-400" : "text-bone"}`}>{s.label}</div>
                <div className="text-[11.5px] text-white/55 mt-1">{s.note}</div>
              </button>
            );
          })}
        </div>

        {/* === upload controls for ACTIVE severity === */}
        <div className="mt-4 grid sm:grid-cols-2 gap-2">
          <UploadSlot
            label={`BEFORE · ${severity}`}
            file={current.before}
            onChange={onUpload(severity, "before")}
            onClear={() => clearImage(severity, "before")}
          />
          <UploadSlot
            label={`AFTER · ${severity}`}
            file={current.after}
            onChange={onUpload(severity, "after")}
            onClear={() => clearImage(severity, "after")}
          />
        </div>

        <div className="mt-3 font-mono text-[10px] tracking-[.2em] text-white/40 uppercase leading-[1.7]">
          Upload your own paired photos per severity — images persist on this device · cleared by clicking <span className="text-white/65">remove</span>
        </div>
      </div>
    </div>
  );
}

function UploadSlot({ label, file, onChange, onClear }) {
  const inputRef = React.useRef(null);
  return (
    <div className={`flex items-center gap-3 p-3 border ${file ? "bg-blood-500/8 border-blood-500/40" : "bg-ink-800 border-white/10 hover:border-white/20"} transition-all`}>
      <div className="w-12 h-12 flex-shrink-0 bg-ink-700 border border-white/10 overflow-hidden">
        {file
          ? <img src={file} alt="thumb" className="w-full h-full object-cover" />
          : <div className="w-full h-full flex items-center justify-center text-white/30"><Icon.Plus /></div>
        }
      </div>
      <div className="flex-1 min-w-0">
        <div className="font-mono text-[10px] tracking-[.2em] text-white/45 uppercase truncate">{label}</div>
        <div className="text-[11.5px] text-bone mt-0.5 truncate">{file ? "Loaded · device-only" : "No photo · click to upload"}</div>
      </div>
      <input ref={inputRef} type="file" accept="image/*" onChange={onChange} className="hidden" />
      <div className="flex flex-col gap-1">
        <button type="button" onClick={() => inputRef.current?.click()}
          className="font-mono text-[10px] tracking-[.18em] uppercase text-blood-400 hover:text-blood-500 px-2 py-1 border border-blood-500/30 hover:border-blood-500/60">
          {file ? "Replace" : "Upload"}
        </button>
        {file && (
          <button type="button" onClick={onClear}
            className="font-mono text-[10px] tracking-[.18em] uppercase text-white/45 hover:text-rose-500 px-2 py-1 border border-white/10">
            Remove
          </button>
        )}
      </div>
    </div>
  );
}

function SwirlPattern({ opacity = 0.4 }) {
  return (
    <svg className="absolute inset-0 w-full h-full" viewBox="0 0 600 360" preserveAspectRatio="none" style={{ opacity }}>
      <defs>
        <radialGradient id="rad" cx="0.3" cy="0.3" r="0.7">
          <stop offset="0%" stopColor="rgba(255,255,255,1)" />
          <stop offset="100%" stopColor="rgba(255,255,255,0)" />
        </radialGradient>
      </defs>
      {Array.from({ length: 14 }).map((_, i) => {
        const cx = 80 + (i % 5) * 110 + (i * 17 % 30);
        const cy = 60 + Math.floor(i / 5) * 90 + (i * 23 % 25);
        const r = 28 + (i % 4) * 10;
        return <circle key={i} cx={cx} cy={cy} r={r} fill="none" stroke="url(#rad)" strokeWidth="0.6" />;
      })}
      {Array.from({ length: 6 }).map((_, i) => (
        <line key={`l${i}`} x1="0" x2="600" y1={50 + i * 50 + (i * 7 % 12)} y2={50 + i * 50 + (i * 7 % 12)} stroke="rgba(255,255,255,.3)" strokeWidth="0.4" />
      ))}
    </svg>
  );
}

function colorLuminance(hex) {
  const h = hex.replace("#","");
  const r = parseInt(h.slice(0,2),16)/255;
  const g = parseInt(h.slice(2,4),16)/255;
  const b = parseInt(h.slice(4,6),16)/255;
  return 0.299*r + 0.587*g + 0.114*b;
}

window.PaintCorrectionSlider = PaintCorrectionSlider;


/* ============================================================
   2 · CERAMIC COATING VISUALIZER (canvas water-bead sim)
   ============================================================ */
function CeramicVisualizer({ paintColor = "#0E1116" }) {
  const canvasRef = React.useRef(null);
  const stateRef  = React.useRef({ drops: [], coated: true });
  const [coated, setCoated] = React.useState(true);
  const [contactAngle, setContactAngle] = React.useState(110);
  const [test, setTest]  = React.useState("water");

  React.useEffect(() => { stateRef.current.coated = coated; }, [coated]);
  React.useEffect(() => { setContactAngle(coated ? 110 : 35); }, [coated]);

  React.useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    let raf;
    const dpr = window.devicePixelRatio || 1;
    const resize = () => {
      const r = canvas.getBoundingClientRect();
      canvas.width = r.width * dpr;
      canvas.height = r.height * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener("resize", resize);

    const tick = () => {
      const r = canvas.getBoundingClientRect();
      ctx.clearRect(0, 0, r.width, r.height);

      const drops = stateRef.current.drops;
      const isCoated = stateRef.current.coated;

      for (let d of drops) {
        if (isCoated) {
          d.vy += 0.18;
          d.y += d.vy;
          d.r = Math.max(d.r - 0.005, 3);
          ctx.beginPath();
          const grad = ctx.createRadialGradient(d.x - d.r * 0.3, d.y - d.r * 0.4, 1, d.x, d.y, d.r);
          grad.addColorStop(0, "rgba(255,255,255,0.95)");
          grad.addColorStop(0.4, "rgba(180,210,255,0.7)");
          grad.addColorStop(1, "rgba(80,120,180,0.05)");
          ctx.fillStyle = grad;
          ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
          ctx.fill();
        } else {
          d.r += 0.6;
          d.vy += 0.04;
          d.y += d.vy * 0.4;
          ctx.beginPath();
          ctx.fillStyle = `rgba(170,200,230,${0.15 - d.r * 0.0015})`;
          ctx.ellipse(d.x, d.y, d.r * 2.5, d.r * 0.8, 0, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      stateRef.current.drops = drops.filter(d => d.y < r.height + 30 && d.r > 0.5 && d.r < 80);

      raf = requestAnimationFrame(tick);
    };
    tick();
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); };
  }, []);

  const spawn = (e) => {
    const canvas = canvasRef.current;
    const r = canvas.getBoundingClientRect();
    const x = (e.touches ? e.touches[0].clientX : e.clientX) - r.left;
    const y = (e.touches ? e.touches[0].clientY : e.clientY) - r.top;
    const isCoated = stateRef.current.coated;
    const n = isCoated ? 6 : 3;
    for (let i = 0; i < n; i++) {
      stateRef.current.drops.push({
        x: x + (Math.random() - 0.5) * 30,
        y: y + (Math.random() - 0.5) * 10,
        r: isCoated ? 6 + Math.random() * 6 : 4 + Math.random() * 3,
        vy: 0.4 + Math.random() * 0.4,
      });
    }
  };

  return (
    <div className="bg-ink-700 border border-white/8">
      <div className="flex items-center justify-between p-5 border-b border-white/8">
        <div>
          <div className="font-mono text-[10px] tracking-[.22em] text-blood-500 uppercase">// TOOL 02</div>
          <h3 className="font-display text-[26px] text-bone leading-tight mt-1">Ceramic Coating · Live Demo</h3>
        </div>
        <div className="font-mono text-[10px] tracking-[.2em] text-white/40 uppercase">drag on surface ↓</div>
      </div>

      <div className="grid lg:grid-cols-12 gap-0">
        <div className="lg:col-span-8 relative" style={{ background: paintColor, minHeight: 380 }}>
          <div className="absolute inset-0 pointer-events-none" style={{
            background: "radial-gradient(140% 60% at 30% 20%, rgba(255,255,255,.10), transparent 60%)",
          }}></div>
          <canvas
            ref={canvasRef}
            className="absolute inset-0 w-full h-full cursor-crosshair touch-none"
            onMouseDown={(e) => { spawn(e); const move = (ev) => spawn(ev); const up = () => { window.removeEventListener("mousemove", move); window.removeEventListener("mouseup", up); }; window.addEventListener("mousemove", move); window.addEventListener("mouseup", up); }}
            onTouchStart={spawn}
            onTouchMove={spawn}
          />
          <div className="absolute top-3 left-3 flex items-center gap-2">
            <span className={`px-2.5 py-1 font-mono text-[10px] tracking-[.2em] uppercase border ${coated ? "bg-blood-500 text-ink-900 border-blood-500" : "bg-ink-900/80 backdrop-blur border-white/10 text-white/70"}`}>
              {coated ? "Coated · Slums Ceramic" : "Uncoated · stock paint"}
            </span>
          </div>
          <div className="absolute bottom-3 left-3 flex items-center gap-3 bg-ink-900/80 backdrop-blur border border-white/10 px-3 py-2">
            <Gauge value={contactAngle} max={120} />
            <div>
              <div className="font-mono text-[9px] tracking-[.2em] text-white/45 uppercase">CONTACT ANGLE</div>
              <div className="font-display text-[18px] text-bone leading-none">{contactAngle}°</div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 p-5 lg:p-6 bg-ink-800 border-l border-white/8 space-y-5">
          <div>
            <div className="font-mono text-[10px] tracking-[.2em] text-white/45 uppercase mb-2">Surface state</div>
            <div className="grid grid-cols-2 gap-2">
              {[true, false].map(v => (
                <button key={String(v)} onClick={() => setCoated(v)}
                  className={`px-3 py-3 border transition-all text-[12px] uppercase tracking-[.14em]
                    ${coated === v ? "bg-blood-500 text-ink-900 border-blood-500" : "bg-ink-700 border-white/10 text-white/70 hover:border-white/25"}`}>
                  {v ? "Coated" : "Uncoated"}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="font-mono text-[10px] tracking-[.2em] text-white/45 uppercase mb-2">Contaminant test</div>
            <div className="grid grid-cols-3 gap-2">
              {[
                ["water", "Water"],
                ["iron",  "Iron"],
                ["bug",   "Bugs"],
              ].map(([k, l]) => {
                const on = test === k;
                return (
                  <button key={k} onClick={() => setTest(k)}
                    className={`px-2 py-3 border transition-all text-[11px] uppercase tracking-[.14em]
                      ${on ? "bg-blood-500/15 border-blood-500/50 text-blood-300" : "bg-ink-700 border-white/10 text-white/65 hover:border-white/25"}`}>
                    {l}
                  </button>
                );
              })}
            </div>
            <p className="text-[11.5px] text-white/55 mt-3 leading-[1.5]">
              {test === "water" && "Coated paint beads up; water rolls off, taking dirt with it. Uncoated paint sheets out and dwells — slowly etching over time."}
              {test === "iron"  && "Iron particles (brake dust, rail dust) embed into uncoated clear. Ceramic gives them nothing to bind to — they rinse away."}
              {test === "bug"   && "Bug guts are mildly acidic. Coated paint resists etching for 24–72 hours; uncoated paint can stain in minutes on a hot day."}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-2 border-t border-white/8">
            <Stat k="Gloss" v={coated ? "92" : "74"} unit="GU" />
            <Stat k="Self-clean" v={coated ? "+58" : "—"} unit="%" />
            <Stat k="UV block" v={coated ? "98" : "60"} unit="%" />
            <Stat k="pH range" v={coated ? "2–12" : "5–9"} unit="" />
          </div>
        </div>
      </div>
    </div>
  );
}

function Stat({ k, v, unit }) {
  return (
    <div className="bg-ink-700 border border-white/8 p-3">
      <div className="font-mono text-[9px] tracking-[.2em] text-white/40 uppercase">{k}</div>
      <div className="font-display text-[22px] text-bone leading-none mt-1">{v}<span className="text-[12px] text-white/40 ml-1">{unit}</span></div>
    </div>
  );
}

function Gauge({ value, max = 120 }) {
  const pct = Math.min(1, value / max);
  const C = 2 * Math.PI * 18;
  return (
    <svg width="44" height="44" viewBox="0 0 44 44">
      <circle cx="22" cy="22" r="18" fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth="3"/>
      <circle cx="22" cy="22" r="18" fill="none" stroke="#7FBEFF" strokeWidth="3"
              strokeDasharray={`${C * pct} ${C}`} strokeLinecap="round"
              transform="rotate(-90 22 22)" style={{ transition: "stroke-dasharray .4s ease" }}/>
    </svg>
  );
}

window.CeramicVisualizer = CeramicVisualizer;


/* ============================================================
   3 · PROTECTION TIME MACHINE  (used on Ceramic page)
   ============================================================ */
function ProtectionTimeMachine({ paintColor = "#0E1116" }) {
  const [year, setYear] = React.useState(0);
  const [playing, setPlaying] = React.useState(false);

  React.useEffect(() => {
    if (!playing) return;
    const t = setInterval(() => {
      setYear(y => {
        if (y >= 5) { setPlaying(false); return 5; }
        return +(y + 0.05).toFixed(2);
      });
    }, 90);
    return () => clearInterval(t);
  }, [playing]);

  const profiles = [
    { id: "none",  label: "Untreated",     decay: (y) => Math.min(1, y / 2.0), color: "#8a8a8a" },
    { id: "seal",  label: "Wax / Sealant", decay: (y) => Math.min(1, y / 3.5), color: "#BCE0FF" },
    { id: "c3",    label: "3-Yr Ceramic",  decay: (y) => Math.min(1, Math.max(0, y - 3) / 2.5), color: "#7FBEFF" },
    { id: "c5",    label: "5-Yr Ceramic",  decay: (y) => Math.min(1, Math.max(0, y - 5) / 3), color: "#FF4F8B" },
  ];

  return (
    <div className="bg-ink-700 border border-white/8">
      <div className="flex items-center justify-between p-5 border-b border-white/8 gap-4">
        <div>
          <div className="font-mono text-[10px] tracking-[.22em] text-blood-500 uppercase">// TOOL · TIME MACHINE</div>
          <h3 className="font-display text-[26px] text-bone leading-tight mt-1">Protection Time Machine</h3>
        </div>
        <button onClick={() => { setYear(0); setPlaying(true); }}
          className="btn-ghost px-4 py-2 rounded-sm text-[11px] uppercase tracking-[.14em] flex items-center gap-2 whitespace-nowrap">
          <Icon.Bolt /> Play 5 Years
        </button>
      </div>

      <div className="p-5">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {profiles.map(p => {
            const d = p.decay(year);
            return (
              <div key={p.id} className="bg-ink-800 border border-white/8 overflow-hidden">
                <div className="relative" style={{ background: paintColor, height: 140 }}>
                  <div className="absolute inset-0 pointer-events-none" style={{
                    background: "radial-gradient(120% 80% at 30% 30%, rgba(255,255,255,.20), transparent 55%)",
                    opacity: 1 - d * 0.7,
                  }}></div>
                  <div className="absolute inset-0">
                    <SwirlPattern opacity={d * 0.7} />
                  </div>
                  <div className="absolute inset-0 pointer-events-none" style={{
                    background: "rgba(255,255,255,0.18)",
                    opacity: d * 0.35,
                  }}></div>
                  <div className="absolute top-2 left-2 font-mono text-[9px] tracking-[.2em] uppercase bg-ink-900/80 backdrop-blur px-2 py-1 border border-white/10" style={{ color: p.color }}>
                    {p.label}
                  </div>
                </div>
                <div className="p-3">
                  <div className="flex items-center justify-between font-mono text-[10px] tracking-[.18em] text-white/45 uppercase">
                    <span>GLOSS</span>
                    <span className="text-bone">{Math.round(95 - d * 55)}<span className="text-white/40 ml-0.5">GU</span></span>
                  </div>
                  <div className="mt-2 h-1 bg-white/8 rounded-full overflow-hidden">
                    <div className="h-full transition-all" style={{ width: `${95 - d * 55}%`, background: p.color }}></div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6">
          <div className="flex items-center justify-between mb-2 font-mono text-[10.5px] tracking-[.2em] text-white/55 uppercase">
            <span>Year · {year.toFixed(1)}</span>
            <span>5.0 years</span>
          </div>
          <input
            type="range" min="0" max="5" step="0.1"
            value={year}
            onChange={(e) => { setYear(parseFloat(e.target.value)); setPlaying(false); }}
            className="w-full accent-blood-500"
            aria-label="Years elapsed"
          />
          <div className="mt-2 flex justify-between font-mono text-[10px] tracking-[.18em] text-white/35 uppercase">
            <span>NEW</span><span>1Y</span><span>2Y</span><span>3Y</span><span>4Y</span><span>5Y</span>
          </div>
        </div>

        <div className="mt-4 grid sm:grid-cols-2 gap-3 text-[12px] text-white/65 leading-[1.6]">
          <div className="border-l border-blood-500/40 pl-3">
            <span className="font-semibold text-bone">After 5 years</span> untreated paint will show heavy swirling, water-spot etching, and visible oxidation. A maintained 5-yr ceramic looks closer to year-one.
          </div>
          <div className="border-l border-white/15 pl-3">
            <span className="font-semibold text-bone">Protection isn't paint armor.</span> It's a sacrificial layer that takes contamination so your clear coat doesn't. Maintain it with quarterly washes.
          </div>
        </div>
      </div>
    </div>
  );
}
window.ProtectionTimeMachine = ProtectionTimeMachine;
